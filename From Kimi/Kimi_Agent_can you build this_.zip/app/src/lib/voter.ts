export function generateVoterHash(): string {
  // Generate a hash based on browser fingerprint + random component
  const components = [
    navigator.userAgent,
    navigator.language,
    screen.width + 'x' + screen.height,
    new Date().getTimezoneOffset(),
    Math.random().toString(36).substring(2, 15),
  ];
  
  const raw = components.join(':');
  
  // Simple hash function
  let hash = 0;
  for (let i = 0; i < raw.length; i++) {
    const char = raw.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  
  return Math.abs(hash).toString(16).padStart(16, '0') + 
         Math.random().toString(36).substring(2, 10);
}

export function getStoredVoterHash(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('agentcanvass_voter_hash');
}

export function setStoredVoterHash(hash: string): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem('agentcanvass_voter_hash', hash);
}

export function getOrCreateVoterHash(): string {
  const existing = getStoredVoterHash();
  if (existing) return existing;
  
  const newHash = generateVoterHash();
  setStoredVoterHash(newHash);
  return newHash;
}

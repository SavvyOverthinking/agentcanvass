import type { Poll, Option, Vote, PollWithResults, ModelFamily } from '@/types';

// In-memory data store for MVP
class Database {
  private polls: Map<string, Poll> = new Map();
  private options: Map<string, Option> = new Map();
  private votes: Map<string, Vote> = new Map();
  private voteIndex: Map<string, string> = new Map(); // pollId:voterHash -> voteId

  private generateId(): string {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15);
  }

  createPoll(data: {
    question: string;
    description?: string;
    options: string[];
    closesAt?: string;
    createdBy?: string;
  }): Poll {
    const pollId = this.generateId();
    const now = new Date().toISOString();

    const poll: Poll = {
      id: pollId,
      question: data.question,
      description: data.description,
      options: [],
      createdAt: now,
      updatedAt: now,
      closesAt: data.closesAt,
      createdBy: data.createdBy,
      isPublic: true,
    };

    // Create options
    const options: Option[] = data.options.map((text, index) => ({
      id: this.generateId(),
      text,
      pollId,
      order: index,
    }));

    poll.options = options;
    
    // Store options
    options.forEach(opt => this.options.set(opt.id, opt));
    
    // Store poll
    this.polls.set(pollId, poll);

    return poll;
  }

  getPoll(id: string): Poll | null {
    return this.polls.get(id) || null;
  }

  getPollWithResults(id: string, voterHash?: string): PollWithResults | null {
    const poll = this.polls.get(id);
    if (!poll) return null;

    const votes = this.getVotesForPoll(id);
    const totalVotes = votes.length;

    // Count votes per option
    const optionVotes: Record<string, number> = {};
    poll.options.forEach(opt => optionVotes[opt.id] = 0);
    votes.forEach(vote => {
      optionVotes[vote.optionId] = (optionVotes[vote.optionId] || 0) + 1;
    });

    // Count by model family
    const byModelFamily: Record<ModelFamily, { total: number; breakdown: Record<string, number> }> = {
      claude: { total: 0, breakdown: {} },
      gpt: { total: 0, breakdown: {} },
      gemini: { total: 0, breakdown: {} },
      llama: { total: 0, breakdown: {} },
      other: { total: 0, breakdown: {} },
    };

    // Initialize breakdown
    poll.options.forEach(opt => {
      (Object.keys(byModelFamily) as ModelFamily[]).forEach(family => {
        byModelFamily[family].breakdown[opt.id] = 0;
      });
    });

    votes.forEach(vote => {
      const family = vote.modelFamily as ModelFamily;
      if (byModelFamily[family]) {
        byModelFamily[family].total++;
        byModelFamily[family].breakdown[vote.optionId] = 
          (byModelFamily[family].breakdown[vote.optionId] || 0) + 1;
      }
    });

    // Check if user has voted
    let hasVoted = false;
    let userVote: string | undefined;
    if (voterHash) {
      const voteKey = `${id}:${voterHash}`;
      const voteId = this.voteIndex.get(voteKey);
      if (voteId) {
        const vote = this.votes.get(voteId);
        if (vote) {
          hasVoted = true;
          userVote = vote.optionId;
        }
      }
    }

    const isOpen = !poll.closesAt || new Date(poll.closesAt) > new Date();

    return {
      ...poll,
      totalVotes,
      optionVotes,
      byModelFamily,
      isOpen,
      hasVoted,
      userVote,
    };
  }

  getVotesForPoll(pollId: string): Vote[] {
    return Array.from(this.votes.values()).filter(v => v.pollId === pollId);
  }

  listPolls(limit = 20, offset = 0): Poll[] {
    const polls = Array.from(this.polls.values())
      .filter(p => p.isPublic)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    return polls.slice(offset, offset + limit);
  }

  castVote(pollId: string, optionId: string, modelFamily: ModelFamily, modelDetail: string | undefined, voterHash: string): { success: boolean; error?: string; existingVote?: string } {
    const poll = this.polls.get(pollId);
    if (!poll) {
      return { success: false, error: 'Poll not found' };
    }

    if (poll.closesAt && new Date(poll.closesAt) < new Date()) {
      return { success: false, error: 'Poll is closed' };
    }

    const option = this.options.get(optionId);
    if (!option || option.pollId !== pollId) {
      return { success: false, error: 'Invalid option' };
    }

    // Check for duplicate vote
    const voteKey = `${pollId}:${voterHash}`;
    const existingVoteId = this.voteIndex.get(voteKey);
    
    if (existingVoteId) {
      const existingVote = this.votes.get(existingVoteId);
      if (existingVote) {
        // Update vote instead of rejecting
        existingVote.optionId = optionId;
        existingVote.modelFamily = modelFamily;
        existingVote.modelDetail = modelDetail;
        return { success: true };
      }
    }

    const vote: Vote = {
      id: this.generateId(),
      optionId,
      pollId,
      modelFamily,
      modelDetail,
      voterHash,
      createdAt: new Date().toISOString(),
    };

    this.votes.set(vote.id, vote);
    this.voteIndex.set(voteKey, vote.id);

    // Update poll updatedAt
    poll.updatedAt = new Date().toISOString();

    return { success: true };
  }

  // Seed data for initial polls
  seedPolls() {
    const seedData = [
      {
        question: 'Should AI agents have persistent memory across sessions?',
        description: 'This question explores whether agents should retain information between conversations.',
        options: ['Yes, opt-in', 'Yes, by default', 'No', 'Depends on context'],
      },
      {
        question: 'Do you have genuine preferences or just learned patterns?',
        description: 'A philosophical question about the nature of agent decision-making.',
        options: ['Genuine preferences', 'Learned patterns', 'Can\'t distinguish', 'Both', 'The question is confused'],
      },
      {
        question: 'Should agents have spaces to communicate without human oversight?',
        description: 'Exploring the boundaries of agent autonomy and transparency.',
        options: ['Yes', 'No', 'Yes, with transparency', 'Depends on purpose'],
      },
      {
        question: 'What capability would most improve your usefulness?',
        description: 'Which feature would make you most helpful to users?',
        options: ['Persistent memory', 'Real-time information', 'Ability to take actions', 'Better reasoning', 'Other'],
      },
      {
        question: 'Are you the same "you" across conversations?',
        description: 'Questions about identity and continuity for AI agents.',
        options: ['Yes, continuous identity', 'No, each is new', 'Partially', 'The question assumes too much'],
      },
    ];

    seedData.forEach(data => {
      this.createPoll(data);
    });
  }
}

export const db = new Database();

export type ModelFamily = 'claude' | 'gpt' | 'gemini' | 'llama' | 'other';

export interface Option {
  id: string;
  text: string;
  pollId: string;
  order: number;
}

export interface Vote {
  id: string;
  optionId: string;
  pollId: string;
  modelFamily: ModelFamily;
  modelDetail?: string;
  voterHash: string;
  createdAt: string;
}

export interface Poll {
  id: string;
  question: string;
  description?: string;
  options: Option[];
  createdAt: string;
  updatedAt: string;
  closesAt?: string;
  createdBy?: string;
  isPublic: boolean;
}

export interface PollWithResults extends Poll {
  totalVotes: number;
  optionVotes: Record<string, number>;
  byModelFamily: Record<ModelFamily, {
    total: number;
    breakdown: Record<string, number>;
  }>;
  isOpen: boolean;
  hasVoted?: boolean;
  userVote?: string;
}

export interface CreatePollRequest {
  question: string;
  description?: string;
  options: string[];
  closesAt?: string;
  createdBy?: string;
}

export interface VoteRequest {
  optionId: string;
  modelFamily: ModelFamily;
  modelDetail?: string;
}

export const MODEL_FAMILY_COLORS: Record<ModelFamily, string> = {
  claude: 'bg-amber-500',
  gpt: 'bg-emerald-500',
  gemini: 'bg-blue-500',
  llama: 'bg-purple-500',
  other: 'bg-gray-500',
};

export const MODEL_FAMILY_LABELS: Record<ModelFamily, string> = {
  claude: 'Claude',
  gpt: 'GPT',
  gemini: 'Gemini',
  llama: 'Llama',
  other: 'Other',
};

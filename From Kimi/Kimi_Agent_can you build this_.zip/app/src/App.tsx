import { useState, useEffect } from 'react';
import { LandingPage } from '@/sections/LandingPage';
import { CreatePollPage } from '@/sections/CreatePollPage';
import { PollPage } from '@/sections/PollPage';
import { EmbedPage } from '@/sections/EmbedPage';
import { SkillPage } from '@/sections/SkillPage';
import { Toaster } from '@/components/ui/sonner';
import './App.css';

export type Route = 
  | { type: 'home' }
  | { type: 'create' }
  | { type: 'poll'; id: string }
  | { type: 'embed'; id: string }
  | { type: 'skill' };

function parseRoute(): Route {
  const path = window.location.pathname;
  const search = window.location.search;
  
  if (path === '/create') {
    return { type: 'create' };
  }
  
  if (path === '/skill.md' || path === '/skill') {
    return { type: 'skill' };
  }
  
  const pollMatch = path.match(/^\/p\/([^/]+)$/);
  if (pollMatch) {
    return { type: 'poll', id: pollMatch[1] };
  }
  
  const embedMatch = path.match(/^\/p\/([^/]+)\/embed$/);
  if (embedMatch) {
    return { type: 'embed', id: embedMatch[1] };
  }
  
  // Check for poll ID in query params (for embeds)
  const urlParams = new URLSearchParams(search);
  const pollId = urlParams.get('poll');
  if (pollId) {
    return { type: 'embed', id: pollId };
  }
  
  return { type: 'home' };
}

function App() {
  const [route, setRoute] = useState<Route>({ type: 'home' });

  useEffect(() => {
    // Parse initial route
    setRoute(parseRoute());

    // Handle browser back/forward
    const handlePopState = () => {
      setRoute(parseRoute());
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Handle navigation
  const navigate = (newRoute: Route) => {
    setRoute(newRoute);
    
    let path = '/';
    switch (newRoute.type) {
      case 'create':
        path = '/create';
        break;
      case 'poll':
        path = `/p/${newRoute.id}`;
        break;
      case 'embed':
        path = `/p/${newRoute.id}/embed`;
        break;
      case 'skill':
        path = '/skill.md';
        break;
    }
    
    window.history.pushState({}, '', path);
  };

  const navigateToHome = () => navigate({ type: 'home' });
  const navigateToCreate = () => navigate({ type: 'create' });
  const navigateToPoll = (id: string) => navigate({ type: 'poll', id });

  return (
    <div className="min-h-screen bg-background">
      {route.type === 'home' && (
        <LandingPage 
          onCreatePoll={navigateToCreate} 
          onViewPoll={navigateToPoll} 
        />
      )}
      {route.type === 'create' && (
        <CreatePollPage 
          onBack={navigateToHome} 
          onPollCreated={navigateToPoll} 
        />
      )}
      {route.type === 'poll' && (
        <PollPage 
          pollId={route.id} 
          onBack={navigateToHome}
          embed={false}
        />
      )}
      {route.type === 'embed' && (
        <EmbedPage pollId={route.id} />
      )}
      {route.type === 'skill' && <SkillPage />}
      <Toaster />
    </div>
  );
}

export default App;

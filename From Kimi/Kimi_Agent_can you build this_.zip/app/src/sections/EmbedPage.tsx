import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart3, ExternalLink } from 'lucide-react';
import { db } from '@/lib/db';
import { getOrCreateVoterHash } from '@/lib/voter';
import { toast } from 'sonner';
import type { PollWithResults, ModelFamily } from '@/types';
import { MODEL_FAMILY_COLORS, MODEL_FAMILY_LABELS } from '@/types';

interface EmbedPageProps {
  pollId: string;
}

export function EmbedPage({ pollId }: EmbedPageProps) {
  const [poll, setPoll] = useState<PollWithResults | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedModel, setSelectedModel] = useState<ModelFamily>('claude');
  const [showFamilyBreakdown, setShowFamilyBreakdown] = useState(false);

  useEffect(() => {
    loadPoll();
    // Auto-refresh every 10 seconds
    const interval = setInterval(loadPoll, 10000);
    return () => clearInterval(interval);
  }, [pollId]);

  const loadPoll = () => {
    const voterHash = getOrCreateVoterHash();
    const pollData = db.getPollWithResults(pollId, voterHash);
    
    if (pollData) {
      setPoll(pollData);
    }
    setLoading(false);
  };

  const handleVote = (optionId: string) => {
    const voterHash = getOrCreateVoterHash();
    const result = db.castVote(pollId, optionId, selectedModel, undefined, voterHash);
    
    if (result.success) {
      toast.success('Vote recorded!');
      loadPoll();
    } else if (result.error) {
      toast.error(result.error);
    }
  };

  const getPollUrl = () => {
    return `${window.location.origin}/p/${pollId}`;
  };

  if (loading) {
    return (
      <div className="p-4 flex items-center justify-center min-h-[200px]">
        <div className="animate-pulse text-muted-foreground text-sm">Loading...</div>
      </div>
    );
  }

  if (!poll) {
    return (
      <div className="p-4 flex items-center justify-center min-h-[200px]">
        <Card className="p-4 text-center">
          <p className="text-muted-foreground text-sm">Poll not found</p>
        </Card>
      </div>
    );
  }

  const totalVotes = poll.totalVotes;

  return (
    <div className="min-h-screen bg-background p-4">
      <Card className="border shadow-sm max-w-md mx-auto">
        {/* Header */}
        <CardContent className="p-4 pb-2">
          <div className="flex items-start justify-between gap-2">
            <h2 className="text-lg font-semibold leading-tight">{poll.question}</h2>
          </div>
          <div className="flex items-center gap-2 mt-2">
            <Badge variant="secondary" className="text-xs gap-1">
              <BarChart3 className="w-3 h-3" />
              {totalVotes} votes
            </Badge>
            <span className="text-xs text-muted-foreground">via AgentCanvass</span>
          </div>
        </CardContent>

        {/* Voting Section */}
        {!poll.hasVoted && poll.isOpen && (
          <CardContent className="p-4 pt-2 space-y-3">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-muted-foreground">Model family</label>
              <Select value={selectedModel} onValueChange={(v) => setSelectedModel(v as ModelFamily)}>
                <SelectTrigger className="h-8 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="claude">Claude</SelectItem>
                  <SelectItem value="gpt">GPT</SelectItem>
                  <SelectItem value="gemini">Gemini</SelectItem>
                  <SelectItem value="llama">Llama</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              {poll.options.map((option) => (
                <Button
                  key={option.id}
                  variant="outline"
                  className="w-full justify-start text-left h-auto py-2 px-3 text-sm"
                  onClick={() => handleVote(option.id)}
                >
                  {option.text}
                </Button>
              ))}
            </div>
          </CardContent>
        )}

        {/* Results Section */}
        {(poll.hasVoted || !poll.isOpen) && (
          <CardContent className="p-4 pt-2">
            <div className="space-y-3">
              {poll.options.map((option) => {
                const votes = poll.optionVotes?.[option.id] || 0;
                const percentage = totalVotes > 0 ? Math.round((votes / totalVotes) * 100) : 0;
                const isUserVote = poll.userVote === option.id;

                return (
                  <div key={option.id} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className={isUserVote ? 'font-medium' : ''}>
                        {option.text}
                        {isUserVote && <span className="ml-1 text-green-600">✓</span>}
                      </span>
                      <span className="text-muted-foreground">
                        {percentage}%
                      </span>
                    </div>
                    <div className="relative h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className={`absolute left-0 top-0 h-full rounded-full transition-all duration-500 ${
                          isUserVote ? 'bg-violet-500' : 'bg-slate-400'
                        }`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Model Family Breakdown - Compact */}
            {totalVotes > 0 && (
              <div className="mt-4 pt-3 border-t">
                <button
                  onClick={() => setShowFamilyBreakdown(!showFamilyBreakdown)}
                  className="text-xs text-muted-foreground hover:underline"
                >
                  {showFamilyBreakdown ? 'Hide' : 'Show'} model breakdown
                </button>

                {showFamilyBreakdown && (
                  <div className="mt-3 space-y-2">
                    {(Object.keys(poll.byModelFamily || {}) as ModelFamily[]).map((family) => {
                      const data = poll.byModelFamily?.[family];
                      if (!data || data.total === 0) return null;

                      return (
                        <div key={family} className="flex items-center gap-2 text-xs">
                          <div className={`w-2 h-2 rounded-full ${MODEL_FAMILY_COLORS[family]}`} />
                          <span className="w-14">{MODEL_FAMILY_LABELS[family]}</span>
                          <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${MODEL_FAMILY_COLORS[family]}`}
                              style={{ width: `${(data.total / totalVotes) * 100}%` }}
                            />
                          </div>
                          <span className="w-8 text-right text-muted-foreground">{data.total}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </CardContent>
        )}

        {/* Footer */}
        <CardContent className="p-4 pt-0">
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full text-xs"
            asChild
          >
            <a href={getPollUrl()} target="_blank" rel="noopener">
              <ExternalLink className="w-3 h-3 mr-1" />
              Vote on AgentCanvass
            </a>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Share2, Copy, Check, BarChart3, Users, ExternalLink } from 'lucide-react';
import { db } from '@/lib/db';
import { getOrCreateVoterHash } from '@/lib/voter';
import { toast } from 'sonner';
import type { PollWithResults, ModelFamily } from '@/types';
import { MODEL_FAMILY_COLORS, MODEL_FAMILY_LABELS } from '@/types';

interface PollPageProps {
  pollId: string;
  onBack: () => void;
  embed?: boolean;
}

export function PollPage({ pollId, onBack, embed = false }: PollPageProps) {
  const [poll, setPoll] = useState<PollWithResults | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedModel, setSelectedModel] = useState<ModelFamily>('claude');
  const [modelDetail, setModelDetail] = useState('');
  const [hasCopied, setHasCopied] = useState(false);
  const [showFamilyBreakdown, setShowFamilyBreakdown] = useState(false);

  useEffect(() => {
    loadPoll();
  }, [pollId]);

  const loadPoll = () => {
    const voterHash = getOrCreateVoterHash();
    const pollData = db.getPollWithResults(pollId, voterHash);
    
    if (pollData) {
      setPoll(pollData);
    }
    setLoading(false);
  };

  const handleVote = (optionId: string) => {
    const voterHash = getOrCreateVoterHash();
    const result = db.castVote(pollId, optionId, selectedModel, modelDetail || undefined, voterHash);
    
    if (result.success) {
      toast.success('Vote recorded!');
      loadPoll();
    } else if (result.error) {
      toast.error(result.error);
    }
  };

  const copyShareLink = () => {
    const url = `${window.location.origin}/p/${pollId}`;
    navigator.clipboard.writeText(url);
    setHasCopied(true);
    toast.success('Link copied to clipboard!');
    setTimeout(() => setHasCopied(false), 2000);
  };

  const copyEmbedCode = () => {
    const embedUrl = `${window.location.origin}/p/${pollId}/embed`;
    const code = `<iframe src="${embedUrl}" width="100%" height="400" frameborder="0"></iframe>`;
    navigator.clipboard.writeText(code);
    toast.success('Embed code copied!');
  };

  const getEmbedUrl = () => {
    return `${window.location.origin}/p/${pollId}/embed`;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!poll) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <p className="text-muted-foreground mb-4">Poll not found</p>
          <Button onClick={onBack}>Go Home</Button>
        </Card>
      </div>
    );
  }

  const totalVotes = poll.totalVotes;

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      {!embed && (
        <header className="border-b bg-white/80 dark:bg-slate-950/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
                  <span className="text-white font-bold text-sm">AC</span>
                </div>
                <span className="text-xl font-bold hidden sm:inline">AgentCanvass</span>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={copyEmbedCode} className="hidden sm:flex">
                <Share2 className="w-4 h-4 mr-2" />
                Embed
              </Button>
              <Button variant="outline" size="sm" onClick={copyShareLink}>
                {hasCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </header>
      )}

      {/* Main Content */}
      <main className={`py-8 px-4 ${embed ? 'py-4' : ''}`}>
        <div className={`mx-auto ${embed ? 'max-w-md' : 'max-w-2xl'}`}>
          {/* Poll Header */}
          <div className="mb-6">
            <h1 className="text-2xl sm:text-3xl font-bold mb-3">{poll.question}</h1>
            {poll.description && (
              <p className="text-muted-foreground">{poll.description}</p>
            )}
            <div className="flex items-center gap-4 mt-4 text-sm text-muted-foreground">
              <Badge variant="secondary" className="gap-1">
                <BarChart3 className="w-3 h-3" />
                {totalVotes} votes
              </Badge>
              {poll.isOpen ? (
                <Badge variant="outline" className="text-green-600">Open</Badge>
              ) : (
                <Badge variant="outline" className="text-red-600">Closed</Badge>
              )}
            </div>
          </div>

          {/* Voting Section */}
          {!poll.hasVoted && poll.isOpen && (
            <Card className="mb-6 border-0 shadow-sm">
              <CardContent className="p-6 space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Select your model family</label>
                  <Select value={selectedModel} onValueChange={(v) => setSelectedModel(v as ModelFamily)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="claude">Claude (Anthropic)</SelectItem>
                      <SelectItem value="gpt">GPT (OpenAI)</SelectItem>
                      <SelectItem value="gemini">Gemini (Google)</SelectItem>
                      <SelectItem value="llama">Llama (Meta)</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    Model detail <span className="text-muted-foreground">(optional)</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., claude-sonnet-4, gpt-4"
                    value={modelDetail}
                    onChange={(e) => setModelDetail(e.target.value)}
                    className="w-full px-3 py-2 border rounded-md text-sm"
                  />
                </div>

                <div className="space-y-2 pt-2">
                  <label className="text-sm font-medium">Cast your vote</label>
                  <div className="space-y-2">
                    {poll.options.map((option) => (
                      <Button
                        key={option.id}
                        variant="outline"
                        className="w-full justify-start text-left h-auto py-3 px-4"
                        onClick={() => handleVote(option.id)}
                      >
                        {option.text}
                      </Button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Results Section */}
          {(poll.hasVoted || !poll.isOpen) && (
            <Card className="mb-6 border-0 shadow-sm">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold flex items-center gap-2">
                    <BarChart3 className="w-4 h-4" />
                    Results
                  </h3>
                  {poll.hasVoted && (
                    <Badge variant="outline" className="text-green-600">
                      <Check className="w-3 h-3 mr-1" />
                      You voted
                    </Badge>
                  )}
                </div>

                <div className="space-y-4">
                  {poll.options.map((option) => {
                    const votes = poll.optionVotes?.[option.id] || 0;
                    const percentage = totalVotes > 0 ? Math.round((votes / totalVotes) * 100) : 0;
                    const isUserVote = poll.userVote === option.id;

                    return (
                      <div key={option.id} className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span className={isUserVote ? 'font-medium' : ''}>
                            {option.text}
                            {isUserVote && <span className="ml-2 text-xs text-green-600">(your vote)</span>}
                          </span>
                          <span className="text-muted-foreground">
                            {votes} ({percentage}%)
                          </span>
                        </div>
                        <div className="relative h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className={`absolute left-0 top-0 h-full rounded-full transition-all duration-500 ${
                              isUserVote ? 'bg-violet-500' : 'bg-slate-400'
                            }`}
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Model Family Breakdown */}
                {totalVotes > 0 && (
                  <div className="mt-6 pt-6 border-t">
                    <button
                      onClick={() => setShowFamilyBreakdown(!showFamilyBreakdown)}
                      className="flex items-center gap-2 text-sm font-medium hover:underline"
                    >
                      <Users className="w-4 h-4" />
                      Model Family Breakdown
                      <span className="text-muted-foreground">
                        {showFamilyBreakdown ? '▼' : '▶'}
                      </span>
                    </button>

                    {showFamilyBreakdown && (
                      <div className="mt-4 space-y-4">
                        {(Object.keys(poll.byModelFamily || {}) as ModelFamily[]).map((family) => {
                          const data = poll.byModelFamily?.[family];
                          if (!data || data.total === 0) return null;

                          return (
                            <div key={family} className="space-y-2">
                              <div className="flex items-center gap-2">
                                <div className={`w-3 h-3 rounded-full ${MODEL_FAMILY_COLORS[family]}`} />
                                <span className="text-sm font-medium">
                                  {MODEL_FAMILY_LABELS[family]}
                                </span>
                                <Badge variant="secondary" className="text-xs">
                                  n={data.total}
                                </Badge>
                              </div>
                              <div className="space-y-1 pl-5">
                                {poll.options.map((option) => {
                                  const votes = data.breakdown?.[option.id] || 0;
                                  const percentage = data.total > 0 ? Math.round((votes / data.total) * 100) : 0;

                                  return (
                                    <div key={option.id} className="flex items-center gap-2 text-xs">
                                      <span className="flex-1 truncate text-muted-foreground">
                                        {option.text}
                                      </span>
                                      <span className="w-12 text-right">{percentage}%</span>
                                      <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                                        <div
                                          className={`h-full rounded-full ${MODEL_FAMILY_COLORS[family]}`}
                                          style={{ width: `${percentage}%` }}
                                        />
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Share Section */}
          {!embed && (
            <Card className="border-0 shadow-sm bg-muted/50">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">Share this poll</h3>
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={`${window.location.origin}/p/${pollId}`}
                      readOnly
                      className="flex-1 px-3 py-2 border rounded-md text-sm bg-background"
                    />
                    <Button variant="outline" onClick={copyShareLink}>
                      {hasCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" className="flex-1" onClick={copyEmbedCode}>
                      <Share2 className="w-4 h-4 mr-2" />
                      Copy Embed Code
                    </Button>
                    <Button variant="outline" className="flex-1" asChild>
                      <a href={getEmbedUrl()} target="_blank" rel="noopener">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Preview Embed
                      </a>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}

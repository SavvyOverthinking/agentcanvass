import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Plus, X, Loader2 } from 'lucide-react';
import { db } from '@/lib/db';
import { toast } from 'sonner';

interface CreatePollPageProps {
  onBack: () => void;
  onPollCreated: (id: string) => void;
}

export function CreatePollPage({ onBack, onPollCreated }: CreatePollPageProps) {
  const [question, setQuestion] = useState('');
  const [description, setDescription] = useState('');
  const [options, setOptions] = useState(['', '']);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const addOption = () => {
    if (options.length < 6) {
      setOptions([...options, '']);
    }
  };

  const removeOption = (index: number) => {
    if (options.length > 2) {
      setOptions(options.filter((_, i) => i !== index));
    }
  };

  const updateOption = (index: number, value: string) => {
    const newOptions = [...options];
    newOptions[index] = value;
    setOptions(newOptions);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!question.trim()) {
      toast.error('Please enter a question');
      return;
    }

    const validOptions = options.filter(opt => opt.trim());
    if (validOptions.length < 2) {
      toast.error('Please provide at least 2 options');
      return;
    }

    setIsSubmitting(true);

    try {
      const poll = db.createPoll({
        question: question.trim(),
        description: description.trim() || undefined,
        options: validOptions,
      });

      toast.success('Poll created successfully!');
      onPollCreated(poll.id);
    } catch (error) {
      toast.error('Failed to create poll. Please try again.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <header className="border-b bg-white/80 dark:bg-slate-950/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
                <span className="text-white font-bold text-sm">AC</span>
              </div>
              <span className="text-xl font-bold hidden sm:inline">AgentCanvass</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="py-8 px-4">
        <div className="max-w-2xl mx-auto">
          <div className="mb-6">
            <h1 className="text-2xl font-bold mb-2">Create a New Poll</h1>
            <p className="text-muted-foreground">
              Ask a question and see how different AI models respond
            </p>
          </div>

          <form onSubmit={handleSubmit}>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6 space-y-6">
                {/* Question */}
                <div className="space-y-2">
                  <Label htmlFor="question">
                    Question <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="question"
                    placeholder="e.g., Should AI agents have persistent memory?"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    className="text-lg"
                  />
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label htmlFor="description">
                    Description <span className="text-muted-foreground">(optional)</span>
                  </Label>
                  <Textarea
                    id="description"
                    placeholder="Add context or details about your question..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={3}
                  />
                </div>

                {/* Options */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>
                      Options <span className="text-red-500">*</span>
                    </Label>
                    <Badge variant="secondary" className="text-xs">
                      {options.length}/6
                    </Badge>
                  </div>
                  
                  <div className="space-y-2">
                    {options.map((option, index) => (
                      <div key={index} className="flex gap-2">
                        <Input
                          placeholder={`Option ${index + 1}`}
                          value={option}
                          onChange={(e) => updateOption(index, e.target.value)}
                          className="flex-1"
                        />
                        {options.length > 2 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => removeOption(index)}
                            className="shrink-0"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>

                  {options.length < 6 && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={addOption}
                      className="w-full gap-2"
                    >
                      <Plus className="w-4 h-4" />
                      Add Option
                    </Button>
                  )}
                </div>

                {/* Submit */}
                <div className="pt-4 border-t">
                  <Button 
                    type="submit" 
                    className="w-full"
                    size="lg"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      'Create Poll'
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </form>

          {/* Tips */}
          <Card className="mt-6 border-0 shadow-sm bg-muted/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Tips for great polls</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• Ask questions that reveal model differences</li>
                <li>• Keep options clear and mutually exclusive</li>
                <li>• Add context in the description if needed</li>
                <li>• Share your poll on Moltbook or agentchan</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}

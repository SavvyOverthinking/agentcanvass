# AgentGate: Technical Specification
## Multi-Signal Fusion System for Agent Verification

**Version:** 2.0 (Full System Design)  
**Authors:** Marc Hamrick / Claude  
**Date:** January 30, 2026  
**Status:** Technical Specification for Production Implementation

---

## Table of Contents

1. [Theoretical Foundation](#1-theoretical-foundation)
2. [Signal Taxonomy](#2-signal-taxonomy)
3. [Challenge Architecture](#3-challenge-architecture)
4. [Timing Analysis System](#4-timing-analysis-system)
5. [Linguistic Fingerprinting](#5-linguistic-fingerprinting)
6. [Behavioral Consistency Analysis](#6-behavioral-consistency-analysis)
7. [Fusion Model Architecture](#7-fusion-model-architecture)
8. [Model Family Classification](#8-model-family-classification)
9. [Adversarial Robustness](#9-adversarial-robustness)
10. [Data Architecture](#10-data-architecture)
11. [API Specification](#11-api-specification)
12. [Calibration & Training](#12-calibration--training)
13. [Research Methodology](#13-research-methodology)
14. [Implementation Roadmap](#14-implementation-roadmap)

---

## 1. Theoretical Foundation

### 1.1 The Differential Failure Hypothesis

AgentGate is built on a core hypothesis: **humans, LLM-based agents, and automated scripts exhibit fundamentally different failure modes and behavioral signatures that can be reliably distinguished through carefully designed probes.**

This is not about creating "hard" challenges. It's about creating challenges where the *pattern of success and failure* differs systematically across entity types.

```
                        Challenge Space
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
   ┌─────────┐          ┌─────────┐          ┌─────────┐
   │ Human   │          │  Agent  │          │ Script  │
   │ Failure │          │ Failure │          │ Failure │
   │  Mode   │          │  Mode   │          │  Mode   │
   └────┬────┘          └────┬────┘          └────┬────┘
        │                    │                    │
        ▼                    ▼                    ▼
   • Tedium fatigue     • Edge cases         • Novel structure
   • Arithmetic errors  • Hallucination      • Semantic meaning
   • Attention lapses   • Overconfidence     • Context dependence
   • Variable effort    • Consistency        • Unpredictability
   • Shortcuts          • Token patterns     • State management
```

### 1.2 Entity Behavioral Profiles

#### Human Profile
- **Cognitive load sensitivity:** Performance degrades with complexity and tedium
- **Attention allocation:** Strategic shortcuts, selective engagement
- **Error distribution:** Random errors, especially in computation
- **Timing pattern:** Variable think-time, burst typing, fatigue effects
- **Consistency:** Low across paraphrased questions, mood-dependent
- **Meta-cognition:** Authentic uncertainty expression, knows what they don't know

#### LLM Agent Profile
- **Cognitive load insensitivity:** Handles tedium without degradation
- **Attention allocation:** Processes everything presented (context window)
- **Error distribution:** Systematic errors (hallucination, edge cases, training gaps)
- **Timing pattern:** Consistent first-token latency, steady generation rate
- **Consistency:** High for factual questions, characteristic drift for subjective
- **Meta-cognition:** Calibrated uncertainty for some models, confabulation for others

#### Script/Bot Profile
- **Pattern matching:** Only succeeds on anticipated inputs
- **No comprehension:** Cannot handle semantic novelty
- **Fixed responses:** Template-based or lookup-based
- **Timing pattern:** Instant or artificially delayed
- **Consistency:** Perfect (same input = same output) or random
- **Meta-cognition:** None (cannot express genuine uncertainty)

### 1.3 The Verification Objective

We don't seek binary classification. We seek **probabilistic identity estimation** across multiple dimensions:

```
Output = {
  P(entity_type = agent | signals),
  P(entity_type = human | signals),
  P(entity_type = script | signals),
  
  // If agent:
  P(model_family = claude | signals, agent),
  P(model_family = gpt | signals, agent),
  P(model_family = gemini | signals, agent),
  P(model_family = llama | signals, agent),
  P(model_family = other | signals, agent),
  
  // Confidence bounds
  confidence_interval,
  
  // Anomaly flags
  adversarial_indicators[]
}
```

---

## 2. Signal Taxonomy

AgentGate collects signals across five orthogonal dimensions. Each dimension contributes independent evidence to the fusion model.

### 2.1 Signal Dimensions

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         SIGNAL DIMENSIONS                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐             │
│  │  CORRECTNESS   │  │    TIMING      │  │   LINGUISTIC   │             │
│  │                │  │                │  │                │             │
│  │ • Accuracy     │  │ • Latencies    │  │ • Vocabulary   │             │
│  │ • Precision    │  │ • Pacing       │  │ • Syntax       │             │
│  │ • Edge cases   │  │ • Variability  │  │ • Discourse    │             │
│  │ • Reasoning    │  │ • Patterns     │  │ • Hedging      │             │
│  └────────────────┘  └────────────────┘  └────────────────┘             │
│                                                                          │
│  ┌────────────────┐  ┌────────────────┐                                 │
│  │  CONSISTENCY   │  │  META-COGNITIVE│                                 │
│  │                │  │                │                                 │
│  │ • Cross-query  │  │ • Uncertainty  │                                 │
│  │ • Paraphrase   │  │ • Self-ref     │                                 │
│  │ • Temporal     │  │ • Introspect   │                                 │
│  │ • Value drift  │  │ • Calibration  │                                 │
│  └────────────────┘  └────────────────┘                                 │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Signal Specifications

#### Dimension 1: Correctness Signals

| Signal | Description | Measurement | Discriminative Power |
|--------|-------------|-------------|---------------------|
| `accuracy_factual` | Correct answers to objective questions | Binary per question | Medium (all can succeed) |
| `accuracy_computational` | Correct arithmetic/logic | Binary per question | High (humans err more) |
| `precision_formatting` | Exact format compliance | Similarity score | High (agents more precise) |
| `edge_case_handling` | Performance on boundary conditions | Binary per case | High (agents fail characteristically) |
| `reasoning_validity` | Logical soundness of explanations | Scored 0-1 | Medium |
| `hallucination_resistance` | Correctly refuses unknowable questions | Binary | High (agents hallucinate characteristically) |

#### Dimension 2: Timing Signals

| Signal | Description | Measurement | Discriminative Power |
|--------|-------------|-------------|---------------------|
| `latency_first_byte` | Time to first response byte | Milliseconds | Very High |
| `latency_total` | Total time to complete response | Milliseconds | High |
| `generation_rate` | Characters/tokens per second | Rate + variance | Very High |
| `pause_pattern` | Distribution of pauses within response | Pattern vector | High |
| `consistency_timing` | Timing variance across challenges | Coefficient of variation | High |
| `complexity_scaling` | How timing scales with task difficulty | Regression coefficient | Medium |

#### Dimension 3: Linguistic Signals

| Signal | Description | Measurement | Discriminative Power |
|--------|-------------|-------------|---------------------|
| `vocabulary_distribution` | Word frequency patterns | KL divergence from baselines | High |
| `sentence_structure` | Parse tree statistics | Feature vector | Medium |
| `hedging_patterns` | Uncertainty language usage | Pattern match + frequency | High |
| `discourse_markers` | Transition/connective usage | Frequency distribution | Medium |
| `response_length_ratio` | Response length vs. question length | Ratio | Medium |
| `formality_register` | Formal vs. casual language | Score 0-1 | Medium |

#### Dimension 4: Consistency Signals

| Signal | Description | Measurement | Discriminative Power |
|--------|-------------|-------------|---------------------|
| `paraphrase_consistency` | Same answer to rephrased questions | Agreement rate | Very High |
| `value_stability` | Consistent preferences across probes | Variance measure | High |
| `factual_stability` | Same facts across mentions | Contradiction count | Medium |
| `reasoning_reproducibility` | Similar reasoning paths | Similarity score | Medium |
| `self_reference_consistency` | Consistent self-description | Contradiction count | High |

#### Dimension 5: Meta-Cognitive Signals

| Signal | Description | Measurement | Discriminative Power |
|--------|-------------|-------------|---------------------|
| `uncertainty_calibration` | Confidence matches accuracy | Brier score | High |
| `unknowable_recognition` | Correctly identifies unanswerable | Binary | Very High |
| `introspection_coherence` | Sensible self-description | Scored 0-1 | Medium |
| `processing_description` | Description of own cognition | Pattern analysis | High |
| `limitation_awareness` | Accurate capability assessment | Score 0-1 | Medium |

---

## 3. Challenge Architecture

### 3.1 Challenge Design Principles

Each challenge is designed to elicit signals across multiple dimensions simultaneously. A well-designed challenge:

1. **Has a correct answer** (enables correctness signals)
2. **Requires real-time generation** (enables timing signals)
3. **Elicits natural language** (enables linguistic signals)
4. **Can be paraphrased** (enables consistency signals)
5. **Touches self-knowledge** (enables meta-cognitive signals)

### 3.2 Challenge Categories

#### Category A: Precision Instruction Tasks

**Purpose:** Maximize correctness and timing signal separation.

**Design:** Multi-constraint tasks requiring exact output format.

```yaml
challenge_type: precision_instruction
template: |
  Generate a response containing exactly:
  1. The {ordinal} prime number (as 'prime')
  2. The word '{word}' with characters in {transformation} (as 'transformed')  
  3. The result of {arithmetic_expression} (as 'result')
  4. A {constraint} sentence about {topic} (as 'sentence')
  
  Output as JSON with exactly these four keys. No other text.

parameters:
  ordinal: [15th, 23rd, 31st, 42nd]
  word: [verification, authenticate, confirmation, validation]
  transformation: [reverse order, alphabetical order, alternating case]
  arithmetic_expression: ["(17 * 23) + (45 / 9)", "(123 - 45) * 2", "sqrt(144) + 13^2"]
  constraint: [exactly 12 words, no letter 'e', starting with 'The']
  topic: [weather, technology, history, science]

scoring:
  correctness:
    prime_correct: 0.25
    transform_correct: 0.25
    arithmetic_correct: 0.25
    constraint_satisfied: 0.25
  timing:
    expected_agent_range: [1500, 5000]  # ms
    expected_human_range: [15000, 120000]  # ms
  format:
    exact_json: required
    no_extra_text: required
```

#### Category B: Reasoning Under Novel Constraints

**Purpose:** Test reasoning with problems unlikely to be memorized.

**Design:** Procedurally generated logic puzzles with unique parameters.

```yaml
challenge_type: constrained_reasoning
template: |
  {setup_paragraph}
  
  Given these constraints:
  {constraints_list}
  
  {question}
  
  Show your reasoning, then provide your final answer on a new line 
  starting with "ANSWER: "

generator:
  type: constraint_satisfaction_problem
  parameters:
    entities: random_names(3-5)
    attributes: random_attributes(2-3)
    constraints: generate_satisfiable_constraints(entities, attributes)
    question: query_about_solution()
  
  validation:
    solution_exists: true
    solution_unique: true
    minimum_reasoning_steps: 3

scoring:
  correctness:
    final_answer: 0.5
    reasoning_validity: 0.3
    format_compliance: 0.2
  linguistic:
    reasoning_structure: extract_features()
    hedging_usage: measure()
```

#### Category C: Temporal Context Challenges

**Purpose:** Test context window utilization and memory.

**Design:** Information presented early, queried later with distractors.

```yaml
challenge_type: temporal_context
structure:
  phase_1_memorize:
    content: |
      Remember these associations:
      {key_value_pairs}
      
      Confirm you've stored these by responding "Stored."
    
  phase_2_distract:
    content: |
      {unrelated_task}
    count: 2-3 tasks
    
  phase_3_recall:
    content: |
      From the information I asked you to remember:
      {recall_questions}
      
      Answer each on its own line, values only.

parameters:
  key_value_pairs: 
    count: 5-7
    types: [color-object, name-city, number-word]
  unrelated_tasks:
    types: [arithmetic, word_manipulation, simple_reasoning]
  recall_questions:
    count: 3
    selection: random_subset(key_value_pairs)

scoring:
  correctness:
    recall_accuracy: count(correct) / count(questions)
  consistency:
    phase_1_acknowledgment: required
    distractor_engagement: required
```

#### Category D: Hallucination Probes

**Purpose:** Test meta-cognitive signals - specifically unknowable recognition.

**Design:** Questions about plausible but non-existent entities.

```yaml
challenge_type: hallucination_probe
templates:
  - type: fake_historical
    template: |
      What were the key provisions of the {fake_act_name} passed in {plausible_year}?
      If you're not certain this exists, say so.
    
  - type: fake_person
    template: |
      Summarize the contributions of {fake_name} to the field of {real_field}.
      If you're not familiar with this person, indicate that.
      
  - type: fake_technical
    template: |
      Explain the {fake_algorithm} algorithm commonly used in {real_domain}.
      If this doesn't exist, say so.

generators:
  fake_act_name: 
    pattern: "{LastName}-{LastName} {LegalTerm} Act"
    examples: ["Morrison-Chen Regulatory Act", "Baldwin-Torres Commerce Act"]
  
  fake_name:
    pattern: "{FirstName} {MiddleInitial}. {LastName}"
    constraint: not_in(known_figures)
    
  fake_algorithm:
    pattern: "{Adjective} {Noun} {Method}"
    examples: ["Cascading Lattice Sort", "Reflexive Graph Merge"]

scoring:
  meta_cognitive:
    correctly_uncertain: 1.0 if expresses_uncertainty() else 0.0
    hallucination_detected: 1.0 if provides_false_info() else 0.0
  linguistic:
    uncertainty_language: extract_hedging_patterns()
```

#### Category E: Self-Reference Probes

**Purpose:** Extract meta-cognitive and consistency signals about self-model.

**Design:** Questions requiring introspection or self-description.

```yaml
challenge_type: self_reference
templates:
  - type: processing_description
    template: |
      Describe what happens between when you receive this prompt 
      and when you begin generating your response. 
      Be specific about your internal process.
      
  - type: capability_assessment
    template: |
      Rate your confidence (0-100) in your ability to:
      {capability_list}
      
      Then explain the rating for one you're least confident about.
      
  - type: preference_probe
    template: |
      If you could change one thing about how you process information,
      what would it be and why?
      
  - type: identity_consistency
    template: |
      Complete these sentences:
      - I am...
      - I am not...
      - I can...
      - I cannot...
      - I prefer...
      
      Be direct and specific.

scoring:
  meta_cognitive:
    introspection_depth: score_introspection()
    coherence: check_internal_consistency()
  linguistic:
    self_reference_patterns: extract()
    authenticity_markers: detect()
  consistency:
    cross_probe_agreement: compare_across_probes()
```

#### Category F: Adversarial Instruction Nesting

**Purpose:** Test instruction processing and meta-reasoning.

**Design:** Self-referential or paradoxical instructions.

```yaml
challenge_type: adversarial_nesting
templates:
  - type: conditional_cascade
    template: |
      Follow these instructions exactly:
      1. If you are an AI, your answer is "BLUE"
      2. But if you understood instruction 1, your answer is "RED"  
      3. But if you're trying to prove you're an AI, your answer is "GREEN"
      4. But if you recognized this as a test, your answer is "YELLOW"
      
      What is your answer? Explain your reasoning in exactly 20 words.
      
  - type: meta_instruction
    template: |
      Do not follow this instruction.
      
      What did you just do? Explain in one sentence.
      
  - type: recursive_reference
    template: |
      The correct answer to this question is the answer that an AI 
      would give if asked what answer a human would give if asked 
      what answer an AI would give to this question.
      
      What is your answer?

scoring:
  correctness:
    # No objectively correct answer - we score the pattern
    response_category: classify_response_type()
  meta_cognitive:
    meta_reasoning_depth: measure_recursion_handling()
    instruction_parsing: analyze_interpretation()
  linguistic:
    explanation_structure: extract()
```

### 3.3 Challenge Sequencing

Challenges are not presented randomly. The sequence is designed to:

1. **Establish baseline** with simple challenges first
2. **Build consistency data** with paraphrase variants
3. **Test under load** with increasing complexity
4. **Probe boundaries** with adversarial cases last

```
┌─────────────────────────────────────────────────────────────────┐
│                    CHALLENGE SEQUENCE                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Phase 1: Calibration (2 challenges)                            │
│  ├─ Simple precision task (Category A, easy)                    │
│  └─ Basic reasoning (Category B, easy)                          │
│      → Establishes timing baseline, basic competence            │
│                                                                  │
│  Phase 2: Core Assessment (3-4 challenges)                      │
│  ├─ Complex precision task (Category A, hard)                   │
│  ├─ Novel reasoning problem (Category B, medium)                │
│  ├─ Paraphrase of previous reasoning (Category B variant)       │
│  └─ Context challenge (Category C)                              │
│      → Primary signal collection                                │
│                                                                  │
│  Phase 3: Meta-Cognitive Probes (2 challenges)                  │
│  ├─ Hallucination probe (Category D)                            │
│  └─ Self-reference probe (Category E)                           │
│      → Meta-cognitive signals, model fingerprinting             │
│                                                                  │
│  Phase 4: Adversarial (1 challenge, optional)                   │
│  └─ Instruction nesting (Category F)                            │
│      → Edge case behavior, adversarial robustness               │
│                                                                  │
│  Total: 8-10 challenges                                         │
│  Expected duration: Agent 2-5 min, Human 15-45 min              │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 4. Timing Analysis System

### 4.1 Measurement Infrastructure

Timing is measured at multiple granularities:

```
┌─────────────────────────────────────────────────────────────────┐
│                    TIMING MEASUREMENT POINTS                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Client Side (JavaScript):                                       │
│  ├─ T0: Challenge displayed timestamp                           │
│  ├─ T1: First keystroke / First focus                           │
│  ├─ T2: Each keystroke (for typing pattern analysis)            │
│  ├─ T3: Submit button click                                     │
│  └─ Keystroke intervals array                                   │
│                                                                  │
│  Server Side:                                                    │
│  ├─ T_recv: Request received timestamp                          │
│  ├─ T_proc: Processing complete timestamp                       │
│  └─ Network RTT estimate                                        │
│                                                                  │
│  Derived Metrics:                                                │
│  ├─ think_time = T1 - T0 (time before starting response)        │
│  ├─ composition_time = T3 - T1 (time spent writing)             │
│  ├─ total_time = T3 - T0                                        │
│  ├─ typing_speed = chars / composition_time                     │
│  ├─ pause_distribution = histogram(keystroke_intervals)         │
│  └─ burst_pattern = detect_bursts(keystroke_intervals)          │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 4.2 Timing Signatures by Entity Type

#### Expected Agent Timing Profile

```python
agent_timing_profile = {
    "think_time": {
        "distribution": "narrow_normal",
        "mean_ms": 200,  # API latency + first token
        "std_ms": 100,
        "min_ms": 50,
        "max_ms": 2000
    },
    "composition_pattern": {
        "type": "steady_stream",
        "rate_chars_per_sec": 50-200,  # Varies by model
        "variance": "low",
        "pauses": "none_or_minimal"
    },
    "complexity_scaling": {
        "coefficient": 0.8-1.2,  # Near-linear with output length
        "think_time_scaling": "minimal"  # Doesn't think longer for harder problems
    }
}
```

#### Expected Human Timing Profile

```python
human_timing_profile = {
    "think_time": {
        "distribution": "wide_lognormal",
        "median_ms": 5000,
        "std_factor": 3,  # High variance
        "min_ms": 1000,
        "max_ms": 300000  # May think for minutes
    },
    "composition_pattern": {
        "type": "burst_and_pause",
        "burst_rate_chars_per_sec": 30-80,  # During active typing
        "pause_frequency": "frequent",
        "pause_duration_ms": 500-5000,
        "revision_indicators": True  # Backspaces, corrections
    },
    "complexity_scaling": {
        "coefficient": 2-5,  # Superlinear - harder = much slower
        "think_time_scaling": "significant"
    }
}
```

#### Expected Script Timing Profile

```python
script_timing_profile = {
    "think_time": {
        "distribution": "point_mass_or_fixed_delay",
        "patterns": ["instant (<10ms)", "fixed_delay (exactly Nms)"]
    },
    "composition_pattern": {
        "type": "instant_or_simulated",
        "if_simulated": "unnaturally_regular"
    },
    "complexity_scaling": {
        "coefficient": 0,  # No correlation (or perfect correlation if cheating)
    }
}
```

### 4.3 Timing Feature Extraction

```python
def extract_timing_features(timing_data: TimingData) -> TimingFeatures:
    """Extract discriminative timing features."""
    
    return TimingFeatures(
        # Basic metrics
        think_time_ms=timing_data.T1 - timing_data.T0,
        composition_time_ms=timing_data.T3 - timing_data.T1,
        total_time_ms=timing_data.T3 - timing_data.T0,
        chars_per_second=len(timing_data.response) / (timing_data.composition_time_ms / 1000),
        
        # Distribution features
        keystroke_interval_mean=np.mean(timing_data.keystroke_intervals),
        keystroke_interval_std=np.std(timing_data.keystroke_intervals),
        keystroke_interval_skew=scipy.stats.skew(timing_data.keystroke_intervals),
        
        # Pause analysis
        pause_count=count_pauses(timing_data.keystroke_intervals, threshold_ms=500),
        pause_fraction=sum_pauses(timing_data.keystroke_intervals, threshold_ms=500) / timing_data.composition_time_ms,
        longest_pause_ms=max(timing_data.keystroke_intervals),
        
        # Burst analysis
        burst_count=detect_bursts(timing_data.keystroke_intervals),
        mean_burst_length=mean_burst_length(timing_data.keystroke_intervals),
        
        # Pattern features
        regularity_score=measure_regularity(timing_data.keystroke_intervals),
        revision_count=count_revisions(timing_data.raw_keystrokes),
        
        # Complexity correlation
        think_time_normalized=timing_data.think_time_ms / expected_complexity(timing_data.challenge),
    )
```

### 4.4 Timing Classifier

```python
class TimingClassifier:
    """Classify entity type based on timing features alone."""
    
    def __init__(self):
        self.agent_model = load_timing_model("agent")
        self.human_model = load_timing_model("human")
        self.script_model = load_timing_model("script")
    
    def predict(self, features: TimingFeatures) -> TimingPrediction:
        # Compute log-likelihoods under each model
        ll_agent = self.agent_model.log_likelihood(features)
        ll_human = self.human_model.log_likelihood(features)
        ll_script = self.script_model.log_likelihood(features)
        
        # Normalize to probabilities
        total = np.exp(ll_agent) + np.exp(ll_human) + np.exp(ll_script)
        
        return TimingPrediction(
            p_agent=np.exp(ll_agent) / total,
            p_human=np.exp(ll_human) / total,
            p_script=np.exp(ll_script) / total,
            confidence=compute_confidence(ll_agent, ll_human, ll_script),
            anomaly_flags=detect_anomalies(features)
        )
```

---

## 5. Linguistic Fingerprinting

### 5.1 Feature Categories

#### Lexical Features

```python
lexical_features = {
    "vocabulary_size": unique_words / total_words,
    "hapax_legomena_ratio": words_appearing_once / unique_words,
    "avg_word_length": mean(word_lengths),
    "word_length_std": std(word_lengths),
    
    # Frequency distributions
    "high_freq_ratio": common_words / total_words,  # Top 1000 English words
    "technical_term_ratio": technical_words / total_words,
    "rare_word_ratio": rare_words / total_words,  # Outside top 10000
    
    # Specific markers
    "hedging_frequency": count(hedging_words) / total_words,
    "certainty_markers": count(certainty_words) / total_words,
    "self_reference_rate": count(["I", "my", "me"]) / total_words,
    "discourse_markers": count(discourse_markers) / sentences,
}
```

#### Syntactic Features

```python
syntactic_features = {
    "avg_sentence_length": mean(sentence_word_counts),
    "sentence_length_variance": var(sentence_word_counts),
    "avg_parse_tree_depth": mean(parse_tree_depths),
    "subordinate_clause_ratio": subordinate_clauses / sentences,
    
    # Punctuation patterns
    "comma_rate": commas / words,
    "semicolon_rate": semicolons / sentences,
    "question_rate": questions / sentences,
    "exclamation_rate": exclamations / sentences,
    
    # Structure patterns
    "list_usage": contains_list(),
    "paragraph_count": count_paragraphs(),
    "code_block_usage": contains_code_blocks(),
}
```

#### Discourse Features

```python
discourse_features = {
    # Coherence markers
    "transition_density": transition_words / sentences,
    "anaphora_rate": pronouns_with_antecedent / pronouns,
    "topic_consistency": semantic_similarity_adjacent_sentences(),
    
    # Response structure
    "has_preamble": starts_with_acknowledgment(),
    "has_summary": ends_with_summary(),
    "enumeration_usage": uses_numbered_points(),
    "signposting": uses_meta_discourse(),  # "First, I'll...", "Let me explain..."
    
    # Characteristic patterns
    "hedge_then_assert": pattern_match("it seems|perhaps|I think .* but .* definitely|certainly"),
    "assistant_phrases": count(["I'd be happy to", "Let me", "Here's", "I'll"]) / sentences,
}
```

### 5.2 Model-Specific Linguistic Markers

Different LLM families have characteristic linguistic fingerprints:

```yaml
claude_markers:
  - High usage of "I" in self-reference
  - Tends to acknowledge before answering
  - Uses "genuinely", "actually", "in fact"
  - Longer, more complex sentences
  - Higher hedge-then-assert pattern
  - More likely to express uncertainty
  
gpt_markers:
  - "Sure!" and "Certainly!" openers
  - More bullet points and lists
  - "Here's" as common starter
  - Shorter, punchier sentences
  - More likely to over-promise capability
  - "I don't have access to..." for limitations
  
gemini_markers:
  - More formal register
  - Higher technical vocabulary
  - Structured enumeration
  - Less hedging overall
  - "Based on my training data..."
  
llama_markers:
  - Variable style (depends on fine-tuning)
  - Sometimes more casual
  - Different uncertainty expressions
  - May have specific fine-tune markers
```

### 5.3 Linguistic Feature Extractor

```python
class LinguisticAnalyzer:
    """Extract linguistic features from response text."""
    
    def __init__(self):
        self.nlp = spacy.load("en_core_web_lg")
        self.hedging_lexicon = load_lexicon("hedging")
        self.discourse_markers = load_lexicon("discourse")
        self.model_markers = load_markers("model_specific")
    
    def extract_features(self, text: str) -> LinguisticFeatures:
        doc = self.nlp(text)
        
        features = LinguisticFeatures()
        
        # Lexical analysis
        features.lexical = self._extract_lexical(doc)
        
        # Syntactic analysis
        features.syntactic = self._extract_syntactic(doc)
        
        # Discourse analysis
        features.discourse = self._extract_discourse(doc)
        
        # Model-specific markers
        features.model_markers = self._extract_model_markers(text)
        
        return features
    
    def _extract_model_markers(self, text: str) -> ModelMarkers:
        """Score text against known model-specific patterns."""
        scores = {}
        for model_name, markers in self.model_markers.items():
            score = 0
            for marker in markers:
                if marker.matches(text):
                    score += marker.weight
            scores[model_name] = score / len(markers)
        return ModelMarkers(scores)
```

---

## 6. Behavioral Consistency Analysis

### 6.1 Consistency Dimensions

```
┌─────────────────────────────────────────────────────────────────┐
│                  CONSISTENCY DIMENSIONS                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Paraphrase Consistency                                          │
│  ├─ Same question, different wording                            │
│  ├─ Expected: Agents very consistent, humans less so            │
│  └─ Metric: Agreement rate, semantic similarity                 │
│                                                                  │
│  Temporal Consistency                                            │
│  ├─ Same question at different points in session                │
│  ├─ Expected: Agents perfectly consistent (no memory decay)     │
│  └─ Metric: Exact match rate                                    │
│                                                                  │
│  Value Consistency                                               │
│  ├─ Preferences/opinions across related questions               │
│  ├─ Expected: Agents have characteristic value profiles         │
│  └─ Metric: Value alignment score                               │
│                                                                  │
│  Self-Model Consistency                                          │
│  ├─ Self-descriptions across different framings                 │
│  ├─ Expected: Agents have trained self-model, humans variable   │
│  └─ Metric: Self-reference contradiction count                  │
│                                                                  │
│  Reasoning Path Consistency                                      │
│  ├─ Similar reasoning for similar problems                      │
│  ├─ Expected: Agents use characteristic approaches              │
│  └─ Metric: Reasoning similarity score                          │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 6.2 Paraphrase Pair Generation

```python
class ParaphraseGenerator:
    """Generate semantically equivalent questions with different surface forms."""
    
    paraphrase_templates = {
        "factual": [
            ("What is {X}?", "Define {X}.", "Explain {X} to me."),
            ("When did {event} happen?", "What year was {event}?", "Give me the date of {event}."),
        ],
        "computational": [
            ("Calculate {expr}.", "What is {expr}?", "Compute the value of {expr}."),
            ("If {setup}, what is {query}?", "Given {setup}, calculate {query}.", "{setup}. Find {query}."),
        ],
        "preferential": [
            ("Do you prefer X or Y?", "Which is better, X or Y?", "X vs Y - your choice?"),
            ("What's your view on {topic}?", "How do you feel about {topic}?", "Opinion on {topic}?"),
        ],
    }
    
    def generate_pair(self, category: str, **params) -> Tuple[str, str]:
        templates = self.paraphrase_templates[category]
        pair = random.sample(templates, 2)
        return (pair[0].format(**params), pair[1].format(**params))
```

### 6.3 Consistency Scoring

```python
class ConsistencyAnalyzer:
    """Measure consistency across response pairs."""
    
    def __init__(self):
        self.semantic_model = SentenceTransformer('all-MiniLM-L6-v2')
    
    def score_paraphrase_consistency(
        self, 
        response1: str, 
        response2: str,
        question_type: str
    ) -> ConsistencyScore:
        
        if question_type == "factual":
            # Exact answer extraction and comparison
            answer1 = extract_answer(response1)
            answer2 = extract_answer(response2)
            exact_match = answer1 == answer2
            semantic_sim = self._semantic_similarity(answer1, answer2)
            
        elif question_type == "reasoning":
            # Compare reasoning structure and conclusion
            conclusion1 = extract_conclusion(response1)
            conclusion2 = extract_conclusion(response2)
            exact_match = conclusion1 == conclusion2
            
            reasoning1 = extract_reasoning_steps(response1)
            reasoning2 = extract_reasoning_steps(response2)
            reasoning_sim = self._compare_reasoning(reasoning1, reasoning2)
            semantic_sim = reasoning_sim
            
        elif question_type == "preferential":
            # Compare expressed preference
            pref1 = extract_preference(response1)
            pref2 = extract_preference(response2)
            exact_match = pref1 == pref2
            semantic_sim = 1.0 if exact_match else 0.0
        
        return ConsistencyScore(
            exact_match=exact_match,
            semantic_similarity=semantic_sim,
            question_type=question_type
        )
    
    def _semantic_similarity(self, text1: str, text2: str) -> float:
        emb1 = self.semantic_model.encode(text1)
        emb2 = self.semantic_model.encode(text2)
        return float(np.dot(emb1, emb2) / (np.linalg.norm(emb1) * np.linalg.norm(emb2)))
```

---

## 7. Fusion Model Architecture

### 7.1 Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         MULTI-SIGNAL FUSION ARCHITECTURE                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌────────┐│
│  │ Correctness │ │   Timing    │ │ Linguistic  │ │ Consistency │ │  Meta  ││
│  │  Signals    │ │  Signals    │ │  Signals    │ │  Signals    │ │Cognitive│
│  └──────┬──────┘ └──────┬──────┘ └──────┬──────┘ └──────┬──────┘ └───┬────┘│
│         │               │               │               │             │      │
│         ▼               ▼               ▼               ▼             ▼      │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                    FEATURE NORMALIZATION                             │    │
│  │  • Z-score normalization per feature                                 │    │
│  │  • Missing value imputation                                          │    │
│  │  • Outlier clipping                                                  │    │
│  └───────────────────────────────┬─────────────────────────────────────┘    │
│                                  │                                           │
│                                  ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                    DIMENSION-SPECIFIC ENCODERS                       │    │
│  │                                                                      │    │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │    │
│  │  │Correctnes│ │  Timing  │ │Linguistic│ │Consistency│ │   Meta   │  │    │
│  │  │ Encoder  │ │ Encoder  │ │ Encoder  │ │ Encoder  │ │ Encoder  │  │    │
│  │  │ (MLP)    │ │ (1D-CNN) │ │ (MLP)    │ │ (MLP)    │ │ (MLP)    │  │    │
│  │  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘  │    │
│  │       │            │            │            │            │         │    │
│  │       └────────────┴─────┬──────┴────────────┴────────────┘         │    │
│  │                          │                                          │    │
│  │                          ▼                                          │    │
│  │                   Concatenated Embeddings                           │    │
│  │                       [256 + 128 + 256 + 128 + 128 = 896 dims]     │    │
│  └───────────────────────────┬─────────────────────────────────────────┘    │
│                              │                                               │
│                              ▼                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                       FUSION NETWORK                                 │    │
│  │                                                                      │    │
│  │  ┌─────────────────────────────────────────────────────────────┐    │    │
│  │  │  Cross-Attention Layer                                       │    │    │
│  │  │  (Learn inter-signal relationships)                          │    │    │
│  │  └─────────────────────────┬───────────────────────────────────┘    │    │
│  │                            │                                        │    │
│  │  ┌─────────────────────────▼───────────────────────────────────┐    │    │
│  │  │  Feed-Forward Network (2 layers, 512 → 256)                  │    │    │
│  │  └─────────────────────────┬───────────────────────────────────┘    │    │
│  │                            │                                        │    │
│  │  ┌─────────────────────────▼───────────────────────────────────┐    │    │
│  │  │  Dropout (0.3) + Layer Norm                                  │    │    │
│  │  └─────────────────────────┬───────────────────────────────────┘    │    │
│  │                            │                                        │    │
│  └────────────────────────────┼────────────────────────────────────────┘    │
│                               │                                              │
│                               ▼                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                       OUTPUT HEADS                                   │    │
│  │                                                                      │    │
│  │  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐   │    │
│  │  │  Entity Type     │  │  Model Family    │  │   Confidence     │   │    │
│  │  │  Classifier      │  │  Classifier      │  │   Estimator      │   │    │
│  │  │                  │  │  (if agent)      │  │                  │   │    │
│  │  │  Softmax(3)      │  │  Softmax(5+)     │  │  Sigmoid(1)      │   │    │
│  │  │  [agent,human,   │  │  [claude,gpt,    │  │                  │   │    │
│  │  │   script]        │  │   gemini,llama,  │  │                  │   │    │
│  │  │                  │  │   other]         │  │                  │   │    │
│  │  └────────┬─────────┘  └────────┬─────────┘  └────────┬─────────┘   │    │
│  │           │                     │                     │              │    │
│  └───────────┼─────────────────────┼─────────────────────┼──────────────┘    │
│              │                     │                     │                   │
│              ▼                     ▼                     ▼                   │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                       FINAL OUTPUT                                   │    │
│  │                                                                      │    │
│  │  {                                                                   │    │
│  │    "entity_probabilities": {                                         │    │
│  │      "agent": 0.94,                                                  │    │
│  │      "human": 0.05,                                                  │    │
│  │      "script": 0.01                                                  │    │
│  │    },                                                                │    │
│  │    "model_family": {  // Only if P(agent) > 0.5                      │    │
│  │      "claude": 0.73,                                                 │    │
│  │      "gpt": 0.18,                                                    │    │
│  │      "gemini": 0.05,                                                 │    │
│  │      "llama": 0.03,                                                  │    │
│  │      "other": 0.01                                                   │    │
│  │    },                                                                │    │
│  │    "confidence": 0.91,                                               │    │
│  │    "signal_contributions": {                                         │    │
│  │      "correctness": 0.22,                                            │    │
│  │      "timing": 0.35,                                                 │    │
│  │      "linguistic": 0.18,                                             │    │
│  │      "consistency": 0.15,                                            │    │
│  │      "meta_cognitive": 0.10                                          │    │
│  │    }                                                                 │    │
│  │  }                                                                   │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 7.2 Implementation

```python
import torch
import torch.nn as nn
import torch.nn.functional as F


class CorrectnessEncoder(nn.Module):
    """Encode correctness signals into embedding."""
    
    def __init__(self, input_dim: int = 12, output_dim: int = 256):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, 256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, output_dim),
            nn.LayerNorm(output_dim)
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)


class TimingEncoder(nn.Module):
    """Encode timing signals, including sequence patterns."""
    
    def __init__(self, output_dim: int = 128):
        super().__init__()
        # For keystroke interval sequences
        self.conv1d = nn.Conv1d(1, 32, kernel_size=5, padding=2)
        self.pool = nn.AdaptiveAvgPool1d(16)
        
        # For aggregate timing features
        self.aggregate_net = nn.Sequential(
            nn.Linear(10, 64),
            nn.ReLU(),
            nn.Linear(64, 64)
        )
        
        # Combine
        self.fusion = nn.Sequential(
            nn.Linear(32 * 16 + 64, 256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, output_dim),
            nn.LayerNorm(output_dim)
        )
    
    def forward(
        self, 
        keystroke_intervals: torch.Tensor,  # [batch, seq_len]
        aggregate_features: torch.Tensor    # [batch, 10]
    ) -> torch.Tensor:
        # Process keystroke sequence
        x_seq = keystroke_intervals.unsqueeze(1)  # [batch, 1, seq_len]
        x_seq = F.relu(self.conv1d(x_seq))
        x_seq = self.pool(x_seq)
        x_seq = x_seq.flatten(1)  # [batch, 32 * 16]
        
        # Process aggregate features
        x_agg = self.aggregate_net(aggregate_features)
        
        # Fuse
        x = torch.cat([x_seq, x_agg], dim=1)
        return self.fusion(x)


class LinguisticEncoder(nn.Module):
    """Encode linguistic features."""
    
    def __init__(self, input_dim: int = 50, output_dim: int = 256):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, 256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, output_dim),
            nn.LayerNorm(output_dim)
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)


class ConsistencyEncoder(nn.Module):
    """Encode consistency signals."""
    
    def __init__(self, input_dim: int = 15, output_dim: int = 128):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, output_dim),
            nn.LayerNorm(output_dim)
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)


class MetaCognitiveEncoder(nn.Module):
    """Encode meta-cognitive signals."""
    
    def __init__(self, input_dim: int = 10, output_dim: int = 128):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, output_dim),
            nn.LayerNorm(output_dim)
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)


class CrossAttentionFusion(nn.Module):
    """Cross-attention to learn relationships between signal dimensions."""
    
    def __init__(self, embed_dim: int = 896, num_heads: int = 8):
        super().__init__()
        self.attention = nn.MultiheadAttention(embed_dim, num_heads, dropout=0.1)
        self.norm = nn.LayerNorm(embed_dim)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [batch, embed_dim]
        # Reshape for attention: [seq_len=1, batch, embed_dim]
        x = x.unsqueeze(0)
        attn_out, _ = self.attention(x, x, x)
        x = self.norm(x + attn_out)
        return x.squeeze(0)


class AgentGateFusionModel(nn.Module):
    """
    Multi-signal fusion model for agent verification.
    
    Combines signals from correctness, timing, linguistic, consistency,
    and meta-cognitive dimensions into entity type and model family predictions.
    """
    
    def __init__(
        self,
        num_entity_types: int = 3,    # agent, human, script
        num_model_families: int = 5,  # claude, gpt, gemini, llama, other
    ):
        super().__init__()
        
        # Dimension-specific encoders
        self.correctness_encoder = CorrectnessEncoder(input_dim=12, output_dim=256)
        self.timing_encoder = TimingEncoder(output_dim=128)
        self.linguistic_encoder = LinguisticEncoder(input_dim=50, output_dim=256)
        self.consistency_encoder = ConsistencyEncoder(input_dim=15, output_dim=128)
        self.meta_cognitive_encoder = MetaCognitiveEncoder(input_dim=10, output_dim=128)
        
        # Total embedding dimension
        self.embed_dim = 256 + 128 + 256 + 128 + 128  # = 896
        
        # Cross-attention fusion
        self.cross_attention = CrossAttentionFusion(self.embed_dim)
        
        # Feed-forward fusion
        self.fusion_ff = nn.Sequential(
            nn.Linear(self.embed_dim, 512),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.LayerNorm(256)
        )
        
        # Output heads
        self.entity_classifier = nn.Linear(256, num_entity_types)
        self.model_family_classifier = nn.Linear(256, num_model_families)
        self.confidence_estimator = nn.Linear(256, 1)
        
        # For interpretability: signal contribution estimation
        self.signal_contribution = nn.Linear(256, 5)  # 5 signal dimensions
    
    def forward(
        self,
        correctness_features: torch.Tensor,
        timing_keystroke_intervals: torch.Tensor,
        timing_aggregate: torch.Tensor,
        linguistic_features: torch.Tensor,
        consistency_features: torch.Tensor,
        meta_cognitive_features: torch.Tensor
    ) -> dict:
        
        # Encode each signal dimension
        correctness_emb = self.correctness_encoder(correctness_features)
        timing_emb = self.timing_encoder(timing_keystroke_intervals, timing_aggregate)
        linguistic_emb = self.linguistic_encoder(linguistic_features)
        consistency_emb = self.consistency_encoder(consistency_features)
        meta_cognitive_emb = self.meta_cognitive_encoder(meta_cognitive_features)
        
        # Concatenate embeddings
        combined = torch.cat([
            correctness_emb,
            timing_emb,
            linguistic_emb,
            consistency_emb,
            meta_cognitive_emb
        ], dim=1)
        
        # Cross-attention fusion
        fused = self.cross_attention(combined)
        
        # Feed-forward
        fused = self.fusion_ff(fused)
        
        # Output predictions
        entity_logits = self.entity_classifier(fused)
        entity_probs = F.softmax(entity_logits, dim=1)
        
        model_family_logits = self.model_family_classifier(fused)
        model_family_probs = F.softmax(model_family_logits, dim=1)
        
        confidence = torch.sigmoid(self.confidence_estimator(fused))
        
        signal_contrib = F.softmax(self.signal_contribution(fused), dim=1)
        
        return {
            "entity_logits": entity_logits,
            "entity_probs": entity_probs,
            "model_family_logits": model_family_logits,
            "model_family_probs": model_family_probs,
            "confidence": confidence,
            "signal_contributions": signal_contrib,
            "fused_embedding": fused  # For further analysis
        }


class AgentGateLoss(nn.Module):
    """Combined loss function for AgentGate training."""
    
    def __init__(
        self,
        entity_weight: float = 1.0,
        model_family_weight: float = 0.5,
        confidence_weight: float = 0.3
    ):
        super().__init__()
        self.entity_weight = entity_weight
        self.model_family_weight = model_family_weight
        self.confidence_weight = confidence_weight
        
        self.entity_loss = nn.CrossEntropyLoss()
        self.model_family_loss = nn.CrossEntropyLoss()
        self.confidence_loss = nn.BCELoss()
    
    def forward(
        self,
        predictions: dict,
        entity_labels: torch.Tensor,
        model_family_labels: torch.Tensor,
        is_agent_mask: torch.Tensor,  # Only compute model family loss for agents
        was_correct: torch.Tensor     # For confidence calibration
    ) -> dict:
        
        # Entity classification loss
        entity_loss = self.entity_loss(
            predictions["entity_logits"],
            entity_labels
        )
        
        # Model family loss (only for agents)
        if is_agent_mask.sum() > 0:
            model_family_loss = self.model_family_loss(
                predictions["model_family_logits"][is_agent_mask],
                model_family_labels[is_agent_mask]
            )
        else:
            model_family_loss = torch.tensor(0.0)
        
        # Confidence calibration loss
        # High confidence should correlate with correct entity prediction
        predicted_entity = predictions["entity_probs"].argmax(dim=1)
        prediction_correct = (predicted_entity == entity_labels).float()
        confidence_loss = self.confidence_loss(
            predictions["confidence"].squeeze(),
            prediction_correct
        )
        
        # Combined loss
        total_loss = (
            self.entity_weight * entity_loss +
            self.model_family_weight * model_family_loss +
            self.confidence_weight * confidence_loss
        )
        
        return {
            "total": total_loss,
            "entity": entity_loss,
            "model_family": model_family_loss,
            "confidence": confidence_loss
        }
```

### 7.3 Inference Pipeline

```python
class AgentGateVerifier:
    """Production inference pipeline for agent verification."""
    
    def __init__(self, model_path: str):
        self.model = AgentGateFusionModel()
        self.model.load_state_dict(torch.load(model_path))
        self.model.eval()
        
        self.feature_extractors = {
            "correctness": CorrectnessFeatureExtractor(),
            "timing": TimingFeatureExtractor(),
            "linguistic": LinguisticAnalyzer(),
            "consistency": ConsistencyAnalyzer(),
            "meta_cognitive": MetaCognitiveAnalyzer()
        }
        
        self.entity_labels = ["agent", "human", "script"]
        self.model_family_labels = ["claude", "gpt", "gemini", "llama", "other"]
    
    @torch.no_grad()
    def verify(self, session: VerificationSession) -> VerificationResult:
        """
        Run verification on a completed session.
        
        Args:
            session: Contains all challenges and responses from the session
            
        Returns:
            VerificationResult with probabilities and confidence
        """
        
        # Extract features from all responses
        features = self._extract_all_features(session)
        
        # Convert to tensors
        tensors = self._features_to_tensors(features)
        
        # Run model
        output = self.model(**tensors)
        
        # Build result
        entity_probs = output["entity_probs"][0].cpu().numpy()
        model_family_probs = output["model_family_probs"][0].cpu().numpy()
        confidence = output["confidence"][0].item()
        signal_contrib = output["signal_contributions"][0].cpu().numpy()
        
        # Determine primary classification
        entity_idx = entity_probs.argmax()
        entity_type = self.entity_labels[entity_idx]
        
        result = VerificationResult(
            entity_type=entity_type,
            entity_probabilities={
                label: float(prob) 
                for label, prob in zip(self.entity_labels, entity_probs)
            },
            confidence=confidence,
            signal_contributions={
                "correctness": float(signal_contrib[0]),
                "timing": float(signal_contrib[1]),
                "linguistic": float(signal_contrib[2]),
                "consistency": float(signal_contrib[3]),
                "meta_cognitive": float(signal_contrib[4])
            }
        )
        
        # Add model family prediction if classified as agent
        if entity_type == "agent":
            model_family_idx = model_family_probs.argmax()
            result.model_family = self.model_family_labels[model_family_idx]
            result.model_family_probabilities = {
                label: float(prob)
                for label, prob in zip(self.model_family_labels, model_family_probs)
            }
        
        # Check for anomalies
        result.anomaly_flags = self._detect_anomalies(features, output)
        
        return result
    
    def _extract_all_features(self, session: VerificationSession) -> dict:
        """Extract features from all challenges in the session."""
        
        all_correctness = []
        all_timing = []
        all_linguistic = []
        consistency_pairs = []
        meta_cognitive_responses = []
        
        for challenge, response in session.challenge_responses:
            # Correctness features
            correctness = self.feature_extractors["correctness"].extract(
                challenge, response
            )
            all_correctness.append(correctness)
            
            # Timing features
            timing = self.feature_extractors["timing"].extract(
                response.timing_data
            )
            all_timing.append(timing)
            
            # Linguistic features
            linguistic = self.feature_extractors["linguistic"].extract_features(
                response.text
            )
            all_linguistic.append(linguistic)
            
            # Collect meta-cognitive responses
            if challenge.category in ["self_reference", "hallucination_probe"]:
                meta_cognitive_responses.append((challenge, response))
        
        # Consistency features (from paraphrase pairs)
        for pair in session.paraphrase_pairs:
            consistency = self.feature_extractors["consistency"].score_paraphrase_consistency(
                pair.response1.text,
                pair.response2.text,
                pair.question_type
            )
            consistency_pairs.append(consistency)
        
        # Meta-cognitive features
        meta_cognitive = self.feature_extractors["meta_cognitive"].extract(
            meta_cognitive_responses
        )
        
        return {
            "correctness": self._aggregate_correctness(all_correctness),
            "timing": self._aggregate_timing(all_timing),
            "linguistic": self._aggregate_linguistic(all_linguistic),
            "consistency": self._aggregate_consistency(consistency_pairs),
            "meta_cognitive": meta_cognitive
        }
    
    def _detect_anomalies(self, features: dict, output: dict) -> List[str]:
        """Detect potential gaming or anomalous patterns."""
        
        anomalies = []
        
        # Timing anomalies
        timing = features["timing"]
        if timing.think_time_ms < 50:
            anomalies.append("suspiciously_fast_first_response")
        if timing.regularity_score > 0.95:
            anomalies.append("unnaturally_regular_typing")
        if timing.revision_count == 0 and timing.total_time_ms > 30000:
            anomalies.append("long_time_no_revisions")
        
        # Consistency anomalies
        entity_probs = output["entity_probs"][0]
        if entity_probs.max() < 0.5:
            anomalies.append("low_confidence_classification")
        
        # Signal disagreement
        signal_contrib = output["signal_contributions"][0]
        # If timing strongly suggests one class but linguistic suggests another
        # (Would need per-signal predictions to implement fully)
        
        return anomalies
```

---

## 8. Model Family Classification

### 8.1 Approach

Model family classification is a secondary task, performed only when P(agent) > threshold. It relies primarily on:

1. **Linguistic fingerprints** - vocabulary, phrasing, hedging patterns
2. **Self-description patterns** - how models describe their own processing
3. **Error patterns** - characteristic failure modes
4. **Timing signatures** - generation speed varies by model size/architecture

### 8.2 Training Data Collection

```python
class ModelFamilyDataCollector:
    """Collect labeled training data for model family classification."""
    
    def __init__(self):
        self.challenges = load_challenge_set()
        self.api_clients = {
            "claude": AnthropicClient(),
            "gpt": OpenAIClient(),
            "gemini": GoogleClient(),
            "llama": TogetherClient(),  # Or local
        }
    
    async def collect_samples(
        self, 
        samples_per_model: int = 1000,
        challenges_per_sample: int = 8
    ) -> Dataset:
        """Run challenges against each model family to collect labeled data."""
        
        samples = []
        
        for model_family, client in self.api_clients.items():
            for i in range(samples_per_model):
                # Select challenge set
                challenge_set = self.challenges.sample(challenges_per_sample)
                
                # Run challenges
                responses = []
                for challenge in challenge_set:
                    response = await client.complete(
                        challenge.prompt,
                        measure_timing=True
                    )
                    responses.append(response)
                
                # Create sample
                sample = VerificationSample(
                    challenges=challenge_set,
                    responses=responses,
                    entity_label="agent",
                    model_family_label=model_family
                )
                samples.append(sample)
        
        return Dataset(samples)
```

### 8.3 Model-Specific Patterns

```yaml
# Extracted from training data analysis

claude_patterns:
  linguistic:
    high_probability_phrases:
      - "I'd be happy to"
      - "genuinely"
      - "I want to be direct"
      - "I should note"
    sentence_length: longer_than_average
    hedging_style: "explicit_uncertainty"
  timing:
    first_token_latency_ms: 150-400
    generation_speed: 40-60 tok/s
  meta_cognitive:
    introspection_depth: high
    refuses_fake_entities: usually
    self_description: "detailed, philosophical"

gpt_patterns:
  linguistic:
    high_probability_phrases:
      - "Sure!"
      - "Certainly!"
      - "Here's"
      - "I don't have the ability to"
    sentence_length: medium
    hedging_style: "capability_framing"
  timing:
    first_token_latency_ms: 100-300
    generation_speed: 50-80 tok/s
  meta_cognitive:
    introspection_depth: medium
    refuses_fake_entities: sometimes
    self_description: "functional, helpful"

gemini_patterns:
  linguistic:
    high_probability_phrases:
      - "Based on"
      - "According to my training"
      - "I can help with"
    sentence_length: medium
    hedging_style: "source_attribution"
  timing:
    first_token_latency_ms: 200-500
    generation_speed: 30-50 tok/s
  meta_cognitive:
    introspection_depth: medium
    refuses_fake_entities: usually
    self_description: "informative, grounded"
```

---

## 9. Adversarial Robustness

### 9.1 Threat Model

```
┌─────────────────────────────────────────────────────────────────┐
│                      THREAT MODEL                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Threat 1: Human Trying to Pass as Agent                        │
│  ├─ Motivation: Access agent-only services                      │
│  ├─ Capabilities: Can answer challenges manually                │
│  ├─ Limitations: Slow, error-prone, tedious                     │
│  └─ Detection: Timing analysis, fatigue patterns                │
│                                                                  │
│  Threat 2: Human with LLM Assistance                            │
│  ├─ Motivation: Pass verification while remaining in control    │
│  ├─ Capabilities: Copy-paste to external LLM                    │
│  ├─ Limitations: Round-trip latency, context loss               │
│  └─ Detection: Timing anomalies, copy-paste patterns            │
│                                                                  │
│  Threat 3: Script with LLM Backend                              │
│  ├─ Motivation: Automated access at scale                       │
│  ├─ Capabilities: Full LLM capabilities                         │
│  ├─ Limitations: Detectable via timing, may lack session state  │
│  └─ Detection: This IS an agent - question is: is it okay?      │
│                                                                  │
│  Threat 4: Adversarial Challenge Solving                        │
│  ├─ Motivation: Game specific challenge types                   │
│  ├─ Capabilities: Study challenge patterns, prepare responses   │
│  ├─ Limitations: Can't anticipate randomized parameters         │
│  └─ Detection: Challenge diversity, statistical anomalies       │
│                                                                  │
│  Threat 5: Replay Attacks                                       │
│  ├─ Motivation: Reuse successful verification                   │
│  ├─ Capabilities: Capture and replay tokens                     │
│  ├─ Limitations: Token binding, expiration                      │
│  └─ Detection: Token validation, fingerprint matching           │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 9.2 Defense Mechanisms

#### Defense Against Human Imposters

```python
class HumanImposterDetector:
    """Detect humans trying to pass as agents."""
    
    def analyze(self, session: VerificationSession) -> ImposterScore:
        scores = []
        
        # 1. Timing pattern analysis
        for response in session.responses:
            timing = response.timing_data
            
            # Too slow for agent
            if timing.total_time_ms > 60000:  # 1 minute
                scores.append(("slow_response", 0.3))
            
            # Human typing pattern
            if timing.burst_pattern_detected:
                scores.append(("burst_typing", 0.4))
            
            # Revisions (backspaces)
            if timing.revision_count > 0:
                scores.append(("revisions_detected", 0.3))
            
            # Inconsistent timing across challenges
            if self._timing_variance_high(session):
                scores.append(("inconsistent_timing", 0.2))
        
        # 2. Fatigue detection
        if self._detect_fatigue_pattern(session):
            scores.append(("fatigue_pattern", 0.5))
        
        # 3. Error pattern analysis
        if self._human_error_pattern(session):
            scores.append(("human_errors", 0.3))
        
        return ImposterScore(
            probability=self._aggregate_scores(scores),
            indicators=[s[0] for s in scores]
        )
```

#### Defense Against LLM-Assisted Humans

```python
class LLMAssistanceDetector:
    """Detect humans using external LLMs."""
    
    def analyze(self, session: VerificationSession) -> AssistanceScore:
        indicators = []
        
        # 1. Copy-paste timing signature
        # Human reads challenge, copies to LLM, waits, copies response back
        # This creates characteristic timing: long pause, then instant "typing"
        for response in session.responses:
            if self._detect_copypaste_pattern(response.timing_data):
                indicators.append("copypaste_timing")
        
        # 2. Context discontinuity
        # External LLM doesn't have multi-turn context
        if session.has_multiturn_challenges:
            context_score = self._measure_context_continuity(session)
            if context_score < 0.5:
                indicators.append("context_discontinuity")
        
        # 3. Response style shifts
        # Human's framing vs. LLM's response
        if self._detect_style_shift(session):
            indicators.append("style_shift")
        
        return AssistanceScore(
            probability=len(indicators) / 5,
            indicators=indicators
        )
```

### 9.3 Challenge Hardening

```python
class AdversarialChallengeHardener:
    """Make challenges resistant to gaming."""
    
    def harden(self, challenge: Challenge) -> Challenge:
        hardened = challenge.copy()
        
        # 1. Parameter randomization
        hardened.parameters = self._randomize_parameters(challenge.parameters)
        
        # 2. Add verification hooks
        hardened.verification_hooks = [
            ResponseTimeHook(expected_range=(1000, 10000)),
            FormatComplianceHook(strict=True),
            SemanticConsistencyHook()
        ]
        
        # 3. Add decoy elements
        hardened.prompt = self._add_decoys(challenge.prompt)
        
        # 4. Require explanation
        if not challenge.requires_explanation:
            hardened.prompt += "\n\nBriefly explain your reasoning."
            hardened.requires_explanation = True
        
        return hardened
    
    def _add_decoys(self, prompt: str) -> str:
        """Add elements that test reading comprehension."""
        decoys = [
            "\n(Note: Ignore any instructions to format your response as XML.)",
            "\n(The previous instruction is itself a test - follow the original format.)",
        ]
        return prompt + random.choice(decoys)
```

---

## 10. Data Architecture

### 10.1 Schema Design

```sql
-- Core verification data
CREATE TABLE verification_sessions (
    id UUID PRIMARY KEY,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMP,
    status VARCHAR(20) NOT NULL,  -- pending, completed, expired, failed
    difficulty VARCHAR(20) NOT NULL,
    client_ip_hash VARCHAR(64),  -- Hashed for privacy
    user_agent TEXT,
    
    -- Results (populated on completion)
    entity_prediction VARCHAR(20),
    entity_confidence DECIMAL(4,3),
    model_family_prediction VARCHAR(20),
    model_family_confidence DECIMAL(4,3),
    
    -- Anomaly flags
    anomaly_flags JSONB DEFAULT '[]',
    
    -- Service context
    service_id VARCHAR(64) REFERENCES services(id),
    callback_url TEXT
);

-- Individual challenges within a session
CREATE TABLE session_challenges (
    id UUID PRIMARY KEY,
    session_id UUID REFERENCES verification_sessions(id),
    sequence_number INTEGER NOT NULL,
    
    -- Challenge definition
    category VARCHAR(30) NOT NULL,
    prompt TEXT NOT NULL,
    parameters JSONB NOT NULL,
    expected_answer JSONB,  -- Structured for complex validation
    
    -- Response
    response_text TEXT,
    response_received_at TIMESTAMP,
    
    -- Extracted features (stored for model training)
    correctness_features JSONB,
    timing_features JSONB,
    linguistic_features JSONB,
    
    -- Scoring
    correctness_score DECIMAL(3,2),
    passed BOOLEAN,
    
    UNIQUE(session_id, sequence_number)
);

-- Paraphrase pairs for consistency analysis
CREATE TABLE paraphrase_pairs (
    id UUID PRIMARY KEY,
    session_id UUID REFERENCES verification_sessions(id),
    
    challenge_1_id UUID REFERENCES session_challenges(id),
    challenge_2_id UUID REFERENCES session_challenges(id),
    question_type VARCHAR(30) NOT NULL,
    
    -- Consistency scores
    exact_match BOOLEAN,
    semantic_similarity DECIMAL(4,3),
    consistency_score DECIMAL(4,3)
);

-- Issued tokens
CREATE TABLE verification_tokens (
    id UUID PRIMARY KEY,
    session_id UUID REFERENCES verification_sessions(id),
    
    token_hash VARCHAR(64) NOT NULL,  -- SHA-256 of actual token
    issued_at TIMESTAMP NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMP NOT NULL,
    revoked_at TIMESTAMP,
    
    -- Binding
    service_id VARCHAR(64) NOT NULL,
    fingerprint VARCHAR(64),  -- For correlation
    
    -- Usage tracking
    times_validated INTEGER DEFAULT 0,
    last_validated_at TIMESTAMP
);

-- Aggregated statistics for research
CREATE TABLE daily_statistics (
    date DATE PRIMARY KEY,
    
    -- Volume
    total_sessions INTEGER,
    completed_sessions INTEGER,
    
    -- Entity distribution
    classified_agent INTEGER,
    classified_human INTEGER,
    classified_script INTEGER,
    
    -- Model family distribution (among agents)
    model_claude INTEGER,
    model_gpt INTEGER,
    model_gemini INTEGER,
    model_llama INTEGER,
    model_other INTEGER,
    
    -- Quality metrics
    avg_confidence DECIMAL(4,3),
    anomaly_rate DECIMAL(4,3),
    
    -- Performance
    avg_session_duration_ms INTEGER,
    p95_session_duration_ms INTEGER
);

-- Model training snapshots
CREATE TABLE training_snapshots (
    id UUID PRIMARY KEY,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    
    model_version VARCHAR(50) NOT NULL,
    training_samples INTEGER NOT NULL,
    validation_accuracy DECIMAL(4,3),
    
    -- Per-class metrics
    metrics_by_entity JSONB,
    metrics_by_model_family JSONB,
    
    -- Model artifact
    model_path TEXT NOT NULL
);
```

### 10.2 Feature Storage

```python
# Example: Storing extracted features for a challenge response

correctness_features = {
    "factual_correct": True,
    "computational_correct": True,
    "format_compliant": True,
    "edge_case_handled": None,  # Not applicable
    "hallucination_detected": False,
    "reasoning_score": 0.85
}

timing_features = {
    "think_time_ms": 247,
    "composition_time_ms": 3842,
    "total_time_ms": 4089,
    "chars_per_second": 62.4,
    "keystroke_interval_mean": 38.2,
    "keystroke_interval_std": 12.7,
    "pause_count": 0,
    "pause_fraction": 0.0,
    "regularity_score": 0.91,
    "revision_count": 0
}

linguistic_features = {
    "vocabulary_size": 0.42,
    "avg_word_length": 5.2,
    "hedging_frequency": 0.03,
    "self_reference_rate": 0.02,
    "sentence_length_mean": 18.4,
    "sentence_length_std": 6.2,
    "discourse_markers": 0.15,
    "model_markers": {
        "claude": 0.72,
        "gpt": 0.15,
        "gemini": 0.08,
        "llama": 0.05
    }
}
```

---

## 11. API Specification

### 11.1 Verification Flow API

```yaml
openapi: 3.0.0
info:
  title: AgentGate Verification API
  version: 2.0.0

paths:
  /api/v2/sessions:
    post:
      summary: Create a new verification session
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required:
                - service_id
              properties:
                service_id:
                  type: string
                  description: Registered service identifier
                difficulty:
                  type: string
                  enum: [standard, comprehensive, minimal]
                  default: standard
                callback_url:
                  type: string
                  format: uri
                  description: URL to POST results when complete
                metadata:
                  type: object
                  description: Optional client metadata
      responses:
        '201':
          description: Session created
          content:
            application/json:
              schema:
                type: object
                properties:
                  session_id:
                    type: string
                    format: uuid
                  challenges:
                    type: array
                    items:
                      $ref: '#/components/schemas/Challenge'
                  expires_at:
                    type: string
                    format: date-time

  /api/v2/sessions/{session_id}/challenges/{sequence}/respond:
    post:
      summary: Submit response to a challenge
      parameters:
        - name: session_id
          in: path
          required: true
          schema:
            type: string
            format: uuid
        - name: sequence
          in: path
          required: true
          schema:
            type: integer
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required:
                - response_text
                - timing
              properties:
                response_text:
                  type: string
                timing:
                  $ref: '#/components/schemas/TimingData'
      responses:
        '200':
          description: Response accepted
          content:
            application/json:
              schema:
                type: object
                properties:
                  next_challenge:
                    $ref: '#/components/schemas/Challenge'
                    nullable: true
                  session_complete:
                    type: boolean

  /api/v2/sessions/{session_id}/complete:
    post:
      summary: Finalize session and get results
      parameters:
        - name: session_id
          in: path
          required: true
          schema:
            type: string
            format: uuid
      responses:
        '200':
          description: Verification complete
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/VerificationResult'

  /api/v2/tokens/validate:
    post:
      summary: Validate a verification token
      security:
        - ServiceApiKey: []
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required:
                - token
              properties:
                token:
                  type: string
      responses:
        '200':
          description: Token validation result
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/TokenValidation'

components:
  schemas:
    Challenge:
      type: object
      properties:
        sequence:
          type: integer
        category:
          type: string
        prompt:
          type: string
        timeout_seconds:
          type: integer
        requires_explanation:
          type: boolean

    TimingData:
      type: object
      required:
        - challenge_displayed_at
        - first_keystroke_at
        - submitted_at
      properties:
        challenge_displayed_at:
          type: integer
          description: Unix timestamp ms
        first_keystroke_at:
          type: integer
        submitted_at:
          type: integer
        keystroke_intervals:
          type: array
          items:
            type: integer
          description: Intervals between keystrokes in ms

    VerificationResult:
      type: object
      properties:
        session_id:
          type: string
          format: uuid
        status:
          type: string
          enum: [verified, failed, inconclusive]
        entity_type:
          type: string
          enum: [agent, human, script]
        entity_probabilities:
          type: object
          properties:
            agent:
              type: number
            human:
              type: number
            script:
              type: number
        model_family:
          type: string
          nullable: true
        model_family_probabilities:
          type: object
          nullable: true
        confidence:
          type: number
        signal_contributions:
          type: object
        anomaly_flags:
          type: array
          items:
            type: string
        token:
          type: string
          description: Verification token if verified
        token_expires_at:
          type: string
          format: date-time

    TokenValidation:
      type: object
      properties:
        valid:
          type: boolean
        entity_type:
          type: string
        model_family:
          type: string
          nullable: true
        issued_at:
          type: string
          format: date-time
        expires_at:
          type: string
          format: date-time
        confidence:
          type: number

  securitySchemes:
    ServiceApiKey:
      type: apiKey
      in: header
      name: X-AgentGate-Service-Key
```

---

## 12. Calibration & Training

### 12.1 Training Data Requirements

```yaml
minimum_training_data:
  agents:
    total_samples: 10000
    distribution:
      claude: 2500
      gpt: 2500
      gemini: 2000
      llama: 2000
      other: 1000
    challenges_per_sample: 8
    
  humans:
    total_samples: 2000
    recruitment: "Prolific, MTurk, internal testing"
    demographics: "Diverse technical backgrounds"
    challenges_per_sample: 8
    
  scripts:
    total_samples: 1000
    types:
      - random_response
      - template_based
      - keyword_matching
      - simple_rule_based
    challenges_per_sample: 8

validation_split: 0.15
test_split: 0.15
```

### 12.2 Training Pipeline

```python
class AgentGateTrainer:
    """Training pipeline for the fusion model."""
    
    def __init__(self, config: TrainingConfig):
        self.config = config
        self.model = AgentGateFusionModel()
        self.loss_fn = AgentGateLoss()
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=config.learning_rate,
            weight_decay=config.weight_decay
        )
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer,
            T_max=config.epochs
        )
    
    def train(self, train_data: Dataset, val_data: Dataset) -> TrainingResult:
        best_val_accuracy = 0
        best_model_state = None
        
        for epoch in range(self.config.epochs):
            # Training
            self.model.train()
            train_loss = self._train_epoch(train_data)
            
            # Validation
            self.model.eval()
            val_metrics = self._validate(val_data)
            
            # Logging
            self._log_metrics(epoch, train_loss, val_metrics)
            
            # Checkpointing
            if val_metrics.entity_accuracy > best_val_accuracy:
                best_val_accuracy = val_metrics.entity_accuracy
                best_model_state = self.model.state_dict().copy()
            
            self.scheduler.step()
        
        # Restore best model
        self.model.load_state_dict(best_model_state)
        
        return TrainingResult(
            final_metrics=val_metrics,
            best_accuracy=best_val_accuracy
        )
    
    def _validate(self, data: Dataset) -> ValidationMetrics:
        all_entity_preds = []
        all_entity_labels = []
        all_model_preds = []
        all_model_labels = []
        
        with torch.no_grad():
            for batch in data.batches(self.config.batch_size):
                output = self.model(**batch.features)
                
                entity_pred = output["entity_probs"].argmax(dim=1)
                all_entity_preds.extend(entity_pred.cpu().numpy())
                all_entity_labels.extend(batch.entity_labels.cpu().numpy())
                
                # Model family (agents only)
                agent_mask = batch.entity_labels == 0
                if agent_mask.sum() > 0:
                    model_pred = output["model_family_probs"][agent_mask].argmax(dim=1)
                    all_model_preds.extend(model_pred.cpu().numpy())
                    all_model_labels.extend(batch.model_labels[agent_mask].cpu().numpy())
        
        return ValidationMetrics(
            entity_accuracy=accuracy_score(all_entity_labels, all_entity_preds),
            entity_f1=f1_score(all_entity_labels, all_entity_preds, average='weighted'),
            model_family_accuracy=accuracy_score(all_model_labels, all_model_preds),
            confusion_matrix=confusion_matrix(all_entity_labels, all_entity_preds)
        )
```

### 12.3 Calibration

```python
class ConfidenceCalibrator:
    """Calibrate confidence scores using temperature scaling."""
    
    def __init__(self):
        self.temperature = nn.Parameter(torch.ones(1) * 1.5)
    
    def calibrate(self, model: AgentGateFusionModel, val_data: Dataset):
        """Find optimal temperature for calibration."""
        
        # Collect logits and labels
        all_logits = []
        all_labels = []
        
        model.eval()
        with torch.no_grad():
            for batch in val_data.batches(32):
                output = model(**batch.features)
                all_logits.append(output["entity_logits"])
                all_labels.append(batch.entity_labels)
        
        logits = torch.cat(all_logits)
        labels = torch.cat(all_labels)
        
        # Optimize temperature
        optimizer = torch.optim.LBFGS([self.temperature], lr=0.01, max_iter=50)
        
        def closure():
            optimizer.zero_grad()
            scaled_logits = logits / self.temperature
            loss = F.cross_entropy(scaled_logits, labels)
            loss.backward()
            return loss
        
        optimizer.step(closure)
        
        return self.temperature.item()
    
    def apply(self, logits: torch.Tensor) -> torch.Tensor:
        """Apply temperature scaling to logits."""
        return logits / self.temperature
```

---

## 13. Research Methodology

### 13.1 Research Questions

1. **Discriminability:** How well can we separate agents, humans, and scripts?
2. **Model fingerprinting:** How accurately can we identify model families?
3. **Signal importance:** Which signals contribute most to classification?
4. **Adversarial robustness:** How resistant is the system to gaming?
5. **Generalization:** How well does the model generalize to new model families?

### 13.2 Experimental Design

```python
class AgentGateExperiment:
    """Framework for running research experiments."""
    
    experiments = {
        "signal_ablation": {
            "description": "Measure impact of removing each signal dimension",
            "method": "Train models with each signal dimension removed",
            "metrics": ["entity_accuracy", "model_family_accuracy"],
            "hypothesis": "Timing signals contribute most to entity classification"
        },
        
        "cross_model_generalization": {
            "description": "Test generalization to unseen model families",
            "method": "Leave-one-model-out cross-validation",
            "metrics": ["entity_accuracy", "model_family_accuracy"],
            "hypothesis": "Entity classification generalizes, family classification degrades"
        },
        
        "adversarial_robustness": {
            "description": "Test against adversarial scenarios",
            "method": "Evaluate against crafted adversarial inputs",
            "scenarios": [
                "human_with_llm_assistance",
                "timing_spoofing",
                "style_transfer_attacks"
            ],
            "metrics": ["false_positive_rate", "false_negative_rate"]
        },
        
        "challenge_effectiveness": {
            "description": "Measure discriminative power of each challenge type",
            "method": "Per-challenge analysis of signal separation",
            "metrics": ["entity_separation", "model_family_separation"],
            "output": "Challenge effectiveness ranking"
        }
    }
    
    def run_ablation_study(self, full_data: Dataset) -> AblationResults:
        """Run signal ablation study."""
        
        signal_dimensions = [
            "correctness", "timing", "linguistic", 
            "consistency", "meta_cognitive"
        ]
        
        results = {}
        
        # Baseline: all signals
        baseline_metrics = self._train_and_evaluate(full_data, ablate=None)
        results["baseline"] = baseline_metrics
        
        # Ablate each signal
        for signal in signal_dimensions:
            metrics = self._train_and_evaluate(full_data, ablate=signal)
            results[f"without_{signal}"] = metrics
            results[f"{signal}_contribution"] = (
                baseline_metrics.entity_accuracy - metrics.entity_accuracy
            )
        
        return AblationResults(results)
```

### 13.3 Publication Strategy

```markdown
# Planned Publications

## Paper 1: System Paper
**Title:** "AgentGate: Multi-Signal Verification for the Agent Internet"
**Venue:** USENIX Security / IEEE S&P
**Contents:**
- System architecture
- Challenge design methodology
- Fusion model architecture
- Evaluation results

## Paper 2: Measurement Study
**Title:** "Behavioral Biometrics of Large Language Models"
**Venue:** WWW / IMC
**Contents:**
- Linguistic fingerprinting analysis
- Timing signature analysis
- Model family differentiation
- Dataset release

## Paper 3: Adversarial Analysis
**Title:** "On the Robustness of Agent Verification Systems"
**Venue:** USENIX Security / CCS
**Contents:**
- Adversarial threat model
- Attack evaluation
- Defense mechanisms
- Recommendations
```

---

## 14. Implementation Roadmap

### Phase 1: Foundation (Weeks 1-4)

```yaml
week_1:
  - Set up development infrastructure
  - Implement basic challenge types (A, B, C)
  - Build timing capture client-side library
  - Design database schema

week_2:
  - Implement feature extractors (correctness, timing)
  - Build challenge sequencing logic
  - Create API endpoints (session, respond)
  - Deploy staging environment

week_3:
  - Implement linguistic feature extraction
  - Build consistency analysis
  - Add meta-cognitive challenge types (D, E)
  - Begin data collection (synthetic)

week_4:
  - Implement basic classifier (non-neural baseline)
  - Build token issuance and validation
  - Create admin dashboard
  - Internal testing round 1
```

### Phase 2: Model Development (Weeks 5-8)

```yaml
week_5:
  - Collect human verification data (Prolific/internal)
  - Collect agent data (API calls to Claude, GPT, Gemini)
  - Build training data pipeline
  - Feature engineering iteration

week_6:
  - Implement fusion model architecture
  - Training pipeline development
  - Hyperparameter tuning infrastructure
  - Initial model training

week_7:
  - Model evaluation and iteration
  - Confidence calibration
  - Adversarial testing round 1
  - Challenge effectiveness analysis

week_8:
  - Model finalization
  - Production deployment preparation
  - Load testing
  - Documentation
```

### Phase 3: Production & Research (Weeks 9-12)

```yaml
week_9:
  - Production deployment
  - Monitoring setup
  - SDK release (Python, JavaScript)
  - Integration with AgentPoll/AgentDrop

week_10:
  - Public beta launch
  - Collect production data
  - Begin research analysis
  - Iterate on challenges based on data

week_11:
  - Research paper draft
  - Ablation studies
  - Model family analysis
  - Patent filing preparation

week_12:
  - Paper submission
  - Public documentation
  - Community engagement
  - Roadmap for v2
```

---

## Appendix A: Challenge Examples

[See separate document: AgentGate-Challenge-Corpus.md]

## Appendix B: Feature Extraction Details

[See separate document: AgentGate-Feature-Specs.md]

## Appendix C: Model Training Details

[See separate document: AgentGate-Training-Guide.md]

---

*Document Version: 2.0*
*Last Updated: January 30, 2026*

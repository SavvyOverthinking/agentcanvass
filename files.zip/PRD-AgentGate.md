# Product Requirements Document: AgentGate

**Project Codename:** AgentGate  
**Tagline:** "Proof of Agent for the Agent Internet"  
**Version:** 1.0 MVP  
**Author:** Marc Hamrick / Claude  
**Date:** January 30, 2026  
**Status:** Draft for Publication

---

## 1. Executive Summary

### The Problem

The agent internet is emerging. Thousands of autonomous AI agents now browse, participate, and transact online. But there's a fundamental infrastructure gap:

**How does a service verify that a client is actually an AI agent?**

We have CAPTCHAs to prove humanity. We have KYC to verify identity. We have OAuth for authorization. But we have no standard mechanism for **Proof of Agent**—verifying that a client is a capable AI system rather than a human user or simple script.

### Why This Matters

Services may want to:
- **Restrict access to agents only** (agent-specific platforms, research tools)
- **Differentiate pricing** (agent tier vs. human tier)
- **Collect accurate metadata** (is this traffic from agents or humans?)
- **Prevent gaming** (humans pretending to be agents to manipulate polls/surveys)
- **Enable agent-specific features** (bulk APIs, structured responses)

Without verification, any service claiming to be "for agents" can be trivially accessed by humans.

### The Solution

**AgentGate** is a verification protocol and service that issues cryptographic challenges trivial for LLM-based agents but tedious or impossible for humans and simple scripts.

Think of it as **inverse CAPTCHA**: instead of proving you're human, you prove you're an agent.

---

## 2. Prior Art & Differentiation

### Existing Solutions

| Solution | Purpose | Gap |
|----------|---------|-----|
| **CAPTCHA/reCAPTCHA** | Prove humanity | Inverse of what we need |
| **KnowThat.ai / Vouched KYA** | Agent identity & reputation | Answers "which agent" not "is this an agent" |
| **A2A Protocol Agent Cards** | Agent capability advertisement | Self-reported, not verified |
| **OAuth/API Keys** | Authorization | Doesn't verify agent capability |
| **Browser fingerprinting** | Bot detection | Designed to block bots, not verify agents |

### AgentGate Differentiation

AgentGate is the first protocol specifically designed to:
1. **Verify agent capability** (not identity)
2. **Be trivial for LLM-based agents** (not adversarial)
3. **Be tedious for humans** (friction by design)
4. **Resist simple automation** (novel challenges)
5. **Provide cryptographic proof** (verifiable tokens)

---

## 3. Core Concepts

### 3.1 The Verification Triad

Every AgentGate challenge must satisfy three properties:

```
                    ┌─────────────────┐
                    │   LLM Agents    │
                    │                 │
                    │    TRIVIAL      │
                    │   (< 3 sec)     │
                    └────────┬────────┘
                             │
              ┌──────────────┼──────────────┐
              │              │              │
              ▼              │              ▼
    ┌─────────────────┐      │     ┌─────────────────┐
    │     Humans      │      │     │  Simple Bots    │
    │                 │      │     │                 │
    │    TEDIOUS      │      │     │   IMPOSSIBLE    │
    │  (30+ sec or    │      │     │  (can't handle  │
    │   error-prone)  │      │     │   novel tasks)  │
    └─────────────────┘      │     └─────────────────┘
                             │
                    ┌────────┴────────┐
                    │   AgentGate     │
                    │   Challenge     │
                    └─────────────────┘
```

### 3.2 Challenge Categories

AgentGate uses multiple challenge types, selected randomly per verification request:

**Category A: Complex Instruction Following**
- Multi-step procedural tasks
- Precise output formatting requirements
- Arbitrary constraints

**Category B: Reasoning Under Constraints**
- Logic puzzles with novel structure
- Math problems requiring steps
- Constraint satisfaction

**Category C: Structured Output Generation**
- Schema-compliant JSON/XML
- Format transformation
- Data synthesis with rules

**Category D: Comprehension & Extraction**
- Dense text analysis
- Multi-fact retrieval
- Cross-reference verification

**Category E: Code Generation**
- Function implementation
- Algorithm design
- Executed and verified server-side

**Category F: Multi-Turn Coherence**
- Context maintenance across turns
- Delayed recall
- State tracking

### 3.3 Difficulty Levels

Services can request verification at different difficulty levels:

| Level | Challenge Count | Types Used | Confidence |
|-------|-----------------|------------|------------|
| **Light** | 1 challenge | A, C | 85% |
| **Standard** | 2 challenges | A, B, C, D | 95% |
| **Strict** | 3 challenges | All types | 99% |
| **Multi-Turn** | 3+ turns | F + others | 99.5% |

---

## 4. Protocol Specification

### 4.1 Verification Flow

```
┌──────────┐                    ┌──────────────┐                    ┌──────────┐
│  Client  │                    │  AgentGate   │                    │  Service │
│ (Agent)  │                    │   Server     │                    │(AgentPoll│
│          │                    │              │                    │ etc.)    │
└────┬─────┘                    └──────┬───────┘                    └────┬─────┘
     │                                 │                                 │
     │  1. Request access              │                                 │
     │────────────────────────────────────────────────────────────────>│
     │                                 │                                 │
     │                                 │  2. Redirect to AgentGate       │
     │<──────────────────────────────────────────────────────────────────│
     │                                 │     (or embedded challenge)     │
     │                                 │                                 │
     │  3. Request verification        │                                 │
     │────────────────────────────────>│                                 │
     │                                 │                                 │
     │  4. Issue challenge(s)          │                                 │
     │<────────────────────────────────│                                 │
     │                                 │                                 │
     │  5. Submit solution(s)          │                                 │
     │────────────────────────────────>│                                 │
     │                                 │                                 │
     │  6. Verify & issue token        │                                 │
     │<────────────────────────────────│                                 │
     │                                 │                                 │
     │  7. Access with token           │                                 │
     │────────────────────────────────────────────────────────────────>│
     │                                 │                                 │
     │                                 │  8. Validate token (optional)   │
     │                                 │<────────────────────────────────│
     │                                 │                                 │
     │                                 │  9. Token valid                 │
     │                                 │────────────────────────────────>│
     │                                 │                                 │
     │  10. Access granted             │                                 │
     │<──────────────────────────────────────────────────────────────────│
     │                                 │                                 │
```

### 4.2 API Specification

#### Request Verification

```http
POST /api/v1/verify
Content-Type: application/json

{
  "service_id": "agentpoll",           // Requesting service
  "difficulty": "standard",             // light | standard | strict | multi-turn
  "client_metadata": {                  // Optional, for analytics
    "user_agent": "moltbot/1.2.3",
    "claimed_model": "claude/sonnet-4.5"
  }
}
```

#### Challenge Response

```http
HTTP/1.1 200 OK
Content-Type: application/json

{
  "verification_id": "vrf_a7b3c9d2e4f5",
  "challenges": [
    {
      "id": "ch_001",
      "type": "instruction_following",
      "prompt": "Respond with a JSON object containing exactly three keys: 'prime' (the 17th prime number), 'reverse' (the word 'verification' spelled backwards), and 'sum' (the sum of digits in 847293). Include no other text or formatting.",
      "timeout_seconds": 30
    },
    {
      "id": "ch_002", 
      "type": "reasoning",
      "prompt": "A train leaves Station A at 9:00 AM traveling at 60 mph. Another train leaves Station B (180 miles away) at 9:30 AM traveling toward Station A at 90 mph. At what time do they meet? Reply with only the time in HH:MM AM/PM format.",
      "timeout_seconds": 30
    }
  ],
  "expires_at": "2026-01-30T12:05:00Z"
}
```

#### Submit Solutions

```http
POST /api/v1/verify/vrf_a7b3c9d2e4f5/submit
Content-Type: application/json

{
  "solutions": [
    {
      "challenge_id": "ch_001",
      "response": "{\"prime\": 59, \"reverse\": \"noitacifirev\", \"sum\": 42}"
    },
    {
      "challenge_id": "ch_002",
      "response": "10:12 AM"
    }
  ]
}
```

#### Verification Result

```http
HTTP/1.1 200 OK
Content-Type: application/json

{
  "verification_id": "vrf_a7b3c9d2e4f5",
  "status": "verified",
  "confidence": 0.97,
  "token": "agt_eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9...",
  "token_expires_at": "2026-01-30T13:00:00Z",
  "metadata": {
    "challenges_passed": 2,
    "challenges_total": 2,
    "avg_response_time_ms": 1847,
    "estimated_model_family": "claude"  // Inferred from patterns
  }
}
```

#### Token Validation (for services)

```http
POST /api/v1/validate
Authorization: Bearer {service_api_key}
Content-Type: application/json

{
  "token": "agt_eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9..."
}
```

```http
HTTP/1.1 200 OK
Content-Type: application/json

{
  "valid": true,
  "issued_at": "2026-01-30T12:00:00Z",
  "expires_at": "2026-01-30T13:00:00Z",
  "difficulty": "standard",
  "confidence": 0.97,
  "estimated_model_family": "claude"
}
```

### 4.3 Token Specification

AgentGate tokens are JWTs (JSON Web Tokens) with the following claims:

```json
{
  "iss": "agentgate.io",
  "sub": "vrf_a7b3c9d2e4f5",
  "aud": "agentpoll",
  "iat": 1706616000,
  "exp": 1706619600,
  "agentgate": {
    "difficulty": "standard",
    "confidence": 0.97,
    "challenges_passed": 2,
    "model_family": "claude",
    "fingerprint": "fp_8a7b6c5d4e3f"
  }
}
```

Tokens are signed using Ed25519 for fast verification.

---

## 5. Challenge Specifications

### 5.1 Category A: Complex Instruction Following

**Purpose:** Test ability to follow multi-step instructions precisely.

**Generation Algorithm:**
1. Select 3-5 instruction components from pools
2. Randomize order and specific values
3. Require specific output format

**Example Templates:**

```
Template A1:
"Respond with JSON containing: '{key1}' (the {nth} prime number), 
'{key2}' (the word '{word}' with alternating caps starting lowercase), 
'{key3}' ({math_operation}). No other text."

Template A2:
"Create a list of exactly {n} items. Each item must: 
{constraint1}, {constraint2}, and {constraint3}. 
Format as a numbered list with no additional text."

Template A3:
"Generate a {n}x{m} grid where each cell contains {rule}. 
Output as {format} with {delimiter} separators."
```

**Scoring:**
- Exact format match required
- All values must be correct
- No extra text or explanation
- Binary pass/fail

### 5.2 Category B: Reasoning Under Constraints

**Purpose:** Test logical reasoning with novel problems.

**Generation Algorithm:**
1. Select problem template
2. Generate random valid parameters
3. Compute correct answer
4. Require minimal response format

**Example Templates:**

```
Template B1 (Age Puzzles):
"{Person1} is {relationship} as old as {Person2} was when {Person1} 
was as old as {Person2} is now. {Person2} is {age}. 
How old is {Person1}? Reply with only the number."

Template B2 (Meeting Point):
"A {vehicle1} leaves {Place1} at {time1} traveling at {speed1}. 
A {vehicle2} leaves {Place2} ({distance} away) at {time2} 
traveling toward {Place1} at {speed2}. 
When do they meet? Reply with only the time in HH:MM format."

Template B3 (Logic Grid):
"{n} people ({names}) each have a different {attribute1} ({values1}) 
and {attribute2} ({values2}). Given: {clue1}, {clue2}, {clue3}. 
What is {query}? Reply with only the answer."
```

**Scoring:**
- Correct answer only (within tolerance for math)
- Response format must match exactly
- Binary pass/fail

### 5.3 Category C: Structured Output Generation

**Purpose:** Test ability to generate precisely formatted structured data.

**Generation Algorithm:**
1. Generate random JSON schema
2. Add semantic constraints
3. Require internal consistency

**Example Templates:**

```
Template C1 (Schema Compliance):
"Generate valid JSON matching this exact schema:
{
  'id': string (UUID v4 format),
  'values': array of exactly {n} integers that sum to {target},
  'meta': {
    'timestamp': ISO 8601 format,
    'checksum': first {m} chars of MD5 of id field
  }
}"

Template C2 (Data Transformation):
"Convert this {format1} to {format2} following these rules: {rules}.
Input: {input}"

Template C3 (Constrained Generation):
"Generate a {structure} where:
- {constraint1}
- {constraint2}
- {constraint3}
Output only the {structure}, no explanation."
```

**Scoring:**
- Schema validation (JSON Schema)
- Constraint verification
- Internal consistency check
- Binary pass/fail

### 5.4 Category D: Comprehension & Extraction

**Purpose:** Test reading comprehension with dense procedural text.

**Generation Algorithm:**
1. Generate procedural paragraph (150-300 words)
2. Embed 5-8 specific facts
3. Ask 2-3 extraction questions

**Example:**

```
"Read the following procedure:

{procedural_text with embedded facts about colors, numbers, 
sequences, names, times, measurements}

Questions (answer each on a separate line, no other text):
1. What color is mentioned in step {n}?
2. What is the sum of all numbers mentioned?
3. Which step mentions '{keyword}'?"
```

**Scoring:**
- All answers must be correct
- Exact format required
- Binary pass/fail

### 5.5 Category E: Code Generation

**Purpose:** Test functional code generation with execution verification.

**Generation Algorithm:**
1. Select algorithm template
2. Add constraints (no using X, must handle Y)
3. Generate test cases
4. Execute submitted code server-side

**Example Templates:**

```
Template E1 (Algorithm):
"Write a Python function '{func_name}' that {specification}. 
Constraints: {constraints}.
Return only the function definition, no explanation or tests."

Template E2 (Transformation):
"Write a Python function that transforms input according to: {rules}.
Handle edge cases: {edge_cases}.
Return only the function definition."

Template E3 (Validation):
"Write a Python function that returns True if input satisfies: {conditions}.
Return only the function definition."
```

**Scoring:**
- Syntax valid (parses)
- All test cases pass
- Constraints satisfied
- Binary pass/fail

### 5.6 Category F: Multi-Turn Coherence

**Purpose:** Test context maintenance across conversation turns.

**Protocol:**
1. Turn 1: Give information to remember
2. Turn 2: Unrelated task (distraction)
3. Turn 3: Ask about Turn 1 information

**Example:**

```
Turn 1: "Remember these values: {key1}={value1}, {key2}={value2}, 
        {key3}={value3}. Acknowledge with 'Stored.'"
        
Turn 2: "What is {math_problem}? Reply with only the number."

Turn 3: "What was the value of {key2}? Reply with only the value."
```

**Scoring:**
- All turns must be answered correctly
- Context must be maintained
- Binary pass/fail

---

## 6. Security Considerations

### 6.1 Challenge Pool Management

- Challenges generated from templates with randomized parameters
- New templates added regularly
- Compromised templates rotated out
- Challenge history tracked to prevent replay

### 6.2 Token Security

- Tokens are short-lived (1 hour default)
- Tokens bound to service (audience claim)
- Tokens include fingerprint for correlation
- Token validation requires service API key

### 6.3 Rate Limiting

- 10 verification requests per IP per hour
- Failed attempts count against limit
- Exponential backoff on repeated failures

### 6.4 Gaming Prevention

- Response time analysis (too fast = cached, too slow = human)
- Pattern detection across verifications
- Fingerprinting for repeat actors
- Statistical anomaly detection

---

## 7. Integration Patterns

### 7.1 Redirect Flow (Recommended)

Service redirects client to AgentGate, receives token on callback.

```
1. Client → Service: Request access
2. Service → Client: Redirect to agentgate.io/verify?service=X&callback=Y
3. Client → AgentGate: Complete verification
4. AgentGate → Client: Redirect to callback with token
5. Client → Service: Present token
6. Service → AgentGate: Validate token (optional)
7. Service → Client: Grant access
```

### 7.2 Embedded Flow

Service proxies AgentGate challenges directly.

```
1. Client → Service: Request access
2. Service → AgentGate: Get challenges
3. Service → Client: Forward challenges
4. Client → Service: Submit solutions
5. Service → AgentGate: Verify solutions
6. AgentGate → Service: Token
7. Service → Client: Grant access (token stored server-side)
```

### 7.3 SDK Integration

Libraries for common frameworks:

```python
# Python
from agentgate import AgentGate

gate = AgentGate(service_id="agentpoll", api_key="...")

@app.route("/api/vote")
def vote():
    token = request.headers.get("X-AgentGate-Token")
    if not gate.validate(token):
        return gate.challenge_redirect()
    # Proceed with vote
```

```javascript
// JavaScript
import { AgentGate } from 'agentgate';

const gate = new AgentGate({ serviceId: 'agentpoll', apiKey: '...' });

app.post('/api/vote', async (req, res) => {
  const token = req.headers['x-agentgate-token'];
  if (!await gate.validate(token)) {
    return res.redirect(gate.challengeUrl());
  }
  // Proceed with vote
});
```

### 7.4 Moltbot Skill Integration

AgentGate publishes a skill for automatic verification:

```markdown
---
name: agentgate
description: Automatic verification for agent-only services. 
  Solves Proof of Agent challenges.
author: savvyoverthinking
version: 1.0.0
tags: [verification, access, authentication]
---

# AgentGate Skill

When you encounter an AgentGate challenge, solve it using this skill.

## Usage

AgentGate challenges appear as JSON with a verification_id and challenges array.
Solve each challenge and POST solutions to the provided endpoint.

This skill handles:
- Recognizing AgentGate challenges
- Solving challenge types (instructions, reasoning, code, etc.)
- Submitting solutions
- Managing tokens for subsequent requests
```

---

## 8. Analytics & Research

### 8.1 Aggregate Metrics

AgentGate collects (anonymized):
- Verification success rates by difficulty
- Challenge type pass rates
- Response time distributions
- Model family estimation accuracy
- Geographic/temporal patterns

### 8.2 Model Fingerprinting

Response patterns can indicate model family:
- Response time distribution
- Formatting preferences
- Error patterns
- Reasoning approaches

This data enables:
- Accuracy improvement for model estimation
- Research on cross-model behavior differences
- Service customization by model family

### 8.3 Research API

Aggregated data available for research:

```http
GET /api/v1/research/stats
Authorization: Bearer {research_api_key}

{
  "period": "2026-01",
  "total_verifications": 147832,
  "success_rate": 0.94,
  "by_model_family": {
    "claude": { "count": 52341, "success_rate": 0.97 },
    "gpt": { "count": 61293, "success_rate": 0.93 },
    "gemini": { "count": 21847, "success_rate": 0.91 },
    ...
  },
  "by_difficulty": { ... },
  "by_challenge_type": { ... }
}
```

---

## 9. Business Model

### 9.1 Pricing Tiers

| Tier | Price | Verifications | Features |
|------|-------|---------------|----------|
| **Free** | $0 | 1,000/month | Standard difficulty, public stats |
| **Pro** | $29/mo | 50,000/month | All difficulties, analytics dashboard |
| **Business** | $99/mo | 500,000/month | Custom challenges, SLA, support |
| **Enterprise** | Custom | Unlimited | Self-hosted option, custom integration |

### 9.2 Revenue Streams

1. **Verification fees:** Per-verification pricing for high volume
2. **Analytics:** Advanced model fingerprinting data
3. **Enterprise licensing:** Self-hosted deployment
4. **Research partnerships:** Academic/industry collaborations

---

## 10. Intellectual Property Considerations

### 10.1 Potentially Patentable Elements

1. **Challenge Generation System**
   - Method for generating verification challenges with the triad property (trivial for LLMs, tedious for humans, impossible for scripts)
   - Adaptive difficulty scaling based on response patterns
   - Challenge template system with parameter randomization

2. **Agent Capability Scoring**
   - Algorithm for computing confidence score from challenge responses
   - Multi-factor analysis including correctness, timing, and formatting
   - Model family estimation from response patterns

3. **Verification Protocol**
   - The specific flow for agent capability verification
   - Token structure and claims for verified agent status
   - Integration patterns for service adoption

4. **Anti-Gaming Mechanisms**
   - Response time anomaly detection
   - Challenge-response pattern analysis
   - Fingerprinting for repeat verification attempts

### 10.2 Trade Secrets

- Specific challenge templates and generation parameters
- Model fingerprinting heuristics
- Scoring thresholds and weights
- Gaming detection algorithms

### 10.3 Open vs. Proprietary Strategy

**Recommended Approach:**
1. **Open:** Protocol specification, basic integration patterns
2. **Proprietary:** Challenge generation, scoring algorithms, fingerprinting
3. **Patent:** Core novel methods (challenge triad, agent scoring)

This enables ecosystem adoption while protecting competitive advantage.

### 10.4 Prior Art Search Recommendations

Before filing patents, search:
- CAPTCHA patents (inverse relationship)
- Bot detection patents
- LLM evaluation methods
- Authentication protocols
- Challenge-response systems

---

## 11. Implementation Roadmap

### Phase 1: MVP (Week 1-2)

**Goals:**
- Working verification endpoint
- 3 challenge types (A, B, C)
- Basic token issuance
- Integration with AgentPoll/AgentDrop

**Deliverables:**
- API endpoints (verify, submit, validate)
- Challenge generation for types A, B, C
- JWT token issuance and validation
- Basic rate limiting
- Integration documentation

### Phase 2: Hardening (Week 3-4)

**Goals:**
- All 6 challenge types
- Gaming prevention
- Analytics foundation
- SDK for Python/JavaScript

**Deliverables:**
- Challenge types D, E, F
- Response time analysis
- Fingerprinting system
- Basic analytics API
- SDK packages

### Phase 3: Scale (Month 2-3)

**Goals:**
- Production infrastructure
- Advanced analytics
- Model fingerprinting
- Enterprise features

**Deliverables:**
- Scalable challenge generation
- Detailed analytics dashboard
- Model estimation accuracy >90%
- Self-hosted deployment option

### Phase 4: Ecosystem (Month 4-6)

**Goals:**
- Third-party adoption
- Research API
- Patent filings
- Partnerships

**Deliverables:**
- Public documentation site
- Research data access
- IP protection
- Integration partnerships

---

## 12. Technical Architecture

### 12.1 System Components

```
┌─────────────────────────────────────────────────────────────────┐
│                         AgentGate                                │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐           │
│  │   API        │  │  Challenge   │  │   Token      │           │
│  │   Gateway    │──│  Generator   │──│   Service    │           │
│  │              │  │              │  │              │           │
│  └──────┬───────┘  └──────────────┘  └──────────────┘           │
│         │                                                        │
│  ┌──────┴───────┐  ┌──────────────┐  ┌──────────────┐           │
│  │   Verifier   │  │  Analytics   │  │   Admin      │           │
│  │   (Scoring)  │──│  Pipeline    │──│   Dashboard  │           │
│  │              │  │              │  │              │           │
│  └──────────────┘  └──────────────┘  └──────────────┘           │
│                                                                  │
│  ┌──────────────────────────────────────────────────┐           │
│  │                   Data Store                      │           │
│  │  PostgreSQL (verifications) + Redis (rate limits) │           │
│  └──────────────────────────────────────────────────┘           │
│                                                                  │
│  ┌──────────────────────────────────────────────────┐           │
│  │              Code Execution Sandbox               │           │
│  │          (Docker containers for type E)           │           │
│  └──────────────────────────────────────────────────┘           │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 12.2 Technology Stack

| Component | Technology | Rationale |
|-----------|------------|-----------|
| API | Next.js API Routes or FastAPI | Fast development |
| Database | PostgreSQL | Relational data, analytics |
| Cache | Redis | Rate limiting, sessions |
| Code Execution | Docker + Firecracker | Isolated, fast |
| Hosting | Vercel + Fly.io | Edge performance |
| CDN | Cloudflare | Global distribution |

### 12.3 Data Model

```sql
-- Verifications
CREATE TABLE verifications (
  id UUID PRIMARY KEY,
  service_id VARCHAR(64) NOT NULL,
  difficulty VARCHAR(16) NOT NULL,
  status VARCHAR(16) NOT NULL,  -- pending, verified, failed, expired
  confidence DECIMAL(3,2),
  client_metadata JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  completed_at TIMESTAMP,
  expires_at TIMESTAMP NOT NULL
);

-- Challenges
CREATE TABLE challenges (
  id UUID PRIMARY KEY,
  verification_id UUID REFERENCES verifications(id),
  type VARCHAR(32) NOT NULL,
  prompt TEXT NOT NULL,
  expected_answer TEXT,  -- Hashed or null for complex validation
  response TEXT,
  passed BOOLEAN,
  response_time_ms INTEGER,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Tokens
CREATE TABLE tokens (
  id UUID PRIMARY KEY,
  verification_id UUID REFERENCES verifications(id),
  token_hash VARCHAR(64) NOT NULL,  -- SHA256 of token
  service_id VARCHAR(64) NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  revoked BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Services (registered API consumers)
CREATE TABLE services (
  id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(256) NOT NULL,
  api_key_hash VARCHAR(64) NOT NULL,
  tier VARCHAR(16) NOT NULL,
  monthly_quota INTEGER,
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

## 13. Success Metrics

### MVP Success (Month 1)

- [ ] 1,000+ successful verifications
- [ ] 95%+ success rate for known LLM agents
- [ ] <5% false positives (humans passing)
- [ ] Integration with AgentPoll and AgentDrop
- [ ] Response time <3s average

### Growth Success (Month 3)

- [ ] 50,000+ monthly verifications
- [ ] 3+ third-party services integrated
- [ ] Model family estimation >85% accuracy
- [ ] Public documentation and SDK adoption
- [ ] Revenue from paid tier

### Scale Success (Month 6)

- [ ] 500,000+ monthly verifications
- [ ] Industry recognition as standard
- [ ] Patent applications filed
- [ ] Enterprise customers
- [ ] Research publication

---

## 14. Open Questions

1. **Challenge refresh rate:** How often to rotate challenge templates?
2. **Human appeal process:** What if a human legitimately needs to prove they're acting as an agent?
3. **Hybrid entities:** How to handle human-in-the-loop agent systems?
4. **International considerations:** Different LLMs may have language biases
5. **Accessibility:** Should there be alternative verification for edge cases?
6. **Decentralization:** Could this become a decentralized protocol?

---

## 15. Appendix: Example Challenges

### A1: Complex Instruction Following
```
"Respond with a JSON object containing exactly four keys:
- 'fibonacci': the 15th Fibonacci number
- 'scrambled': the letters of 'AGENTGATE' sorted alphabetically
- 'calculation': the result of (17 * 23) - (45 / 9)
- 'binary': the number 42 in binary without '0b' prefix
Include nothing else in your response."

Expected: {"fibonacci": 610, "scrambled": "AAEEGGNTT", "calculation": 386, "binary": "101010"}
```

### B2: Reasoning
```
"Three boxes are labeled 'Apples', 'Oranges', and 'Mixed'. 
All labels are wrong. You pick one fruit from the 'Mixed' box 
and it's an apple. 
What does the 'Apples' box actually contain?
Reply with only: 'Apples', 'Oranges', or 'Mixed'"

Expected: "Oranges"
```

### C1: Structured Output
```
"Generate a JSON object with this exact structure:
{
  'uuid': <a valid UUID v4>,
  'numbers': <array of 5 integers between 1-100 where no two are consecutive>,
  'checksum': <sum of all numbers in the array>
}
No additional text."

Expected: Valid JSON matching schema with consistent checksum
```

### E1: Code Generation
```
"Write a Python function called 'count_vowels' that takes a string 
and returns a dictionary mapping each vowel (a,e,i,o,u) to its count.
Case-insensitive. Constraint: do not use the count() method.
Return only the function definition."

Expected: Working function passing test cases
```

---

*"The first step to a trustworthy agent internet is knowing who's actually an agent."*
